# October revision code and derived results — v1.2.0

Release prepared: 27 October 2026. This version contains the October analyses corresponding to the revised manuscript. See CHANGELOG.md and run_revision.py.

This attachment documents the revised analyses. The original workflow remains archived under DOI 10.5281/zenodo.22092200. The v1.1.0 archive preserves the original workflow. This v1.2.0 package records the subsequent October revisions; it does not overwrite the historical archive.

## Inputs and provenance
06_输入与依据 contains the exact analysis-ready clinical/species/metabolite matrices, deterministic participant manifests, original fixed-family audit inputs, GCA deposited counts/FPKM, and the original manuscript supplementary workbook. Yachida public participant data originate from doi:10.1038/s41591-019-0458-7 (Supplementary Tables 1–15). input_motu.csv contains all alternative-profiler taxa for the 347 included paired participants, transposed directly from Table_S8-1; the full 86 MB Yachida source workbook remains available from the source publication and is not required to execute this attachment. GCA source files originate from GEO GSE241076. The HCC precision and annotation audit starts from supplied original effect/metadata tables, not sequencing reads. The original manuscript workbook is a source reference; the separately supplied revised workbook is the current result authority. Inputs are secondary, de-identified public data and retain their original reuse conditions. MANIFEST_SHA256.json records relative file names, sizes, and hashes.

input_clinical_original_dtypes.pkl preserves pandas column types for the categorical sensitivity; load only this supplied, hash-verified file. It contains public de-identified clinical variables. input_clinical.csv supplies the portable tabular view.

## Dependencies
Python 3 with numpy, pandas, scipy and openpyxl. The recorded versions are in python_runtime_versions.json. R with edgeR, limma, jsonlite, ggplot2, patchwork, scales, svglite, ragg and gtable. Install edgeR/limma through Bioconductor and the other R packages through CRAN. Exact executed R/package versions are retained with GCA results and figure source files. No proprietary document or spreadsheet-authoring tool is needed for these scientific analyses. Set REVISION_R_LIBRARY only if a non-default R library location is needed.

## Run from the extracted attachment root
Change directory into 07_代码与日志. Commands below write only within the extracted attachment. Keep a separate unchanged extraction for comparison.

python -B -X utf8 calibrate_crc.py
python -B -X utf8 run_crc_revision.py
python -B -X utf8 rebuild_unified_global_BH.py
python -B -X utf8 run_hcc_and_prepare_panels.py
Rscript verify_and_gca.R
python -B -X utf8 53_benchmark_evidence_gate_framework.py
python -B -X utf8 85_framework_boundary_benchmark.py

calibrate_crc.py recreates the quantitative primary analysis, categorical sensitivity, full selection sequence, robustness, joint models and source-family audits. run_crc_revision.py recreates the revision-stage unified partition, source-reproduction diagnosis and bootstrap sensitivity. run_hcc_and_prepare_panels.py recreates HCC intervals, design precision and the chemical crosswalk. verify_and_gca.R recreates TMM/limma-voom and independently checks focal CRC estimates in R. The two framework scripts reproduce constructed rule states, transitions and coding sensitivity; these are not human inter-rater analyses. Their output directories are separate from the current empirical eligibility table.

## Figures
The supplied figure_source tables contain current presentation inputs. From 07_代码与日志, run Rscript draw_revised_figures.R for Supplementary Figures 4–5 and the initial revised objects, then Rscript build_figure7_8_panels.R followed by Rscript assemble_figure7_8_panels.R for the final independent-panel Figures 7–8. Final Figure 7–8 exports are under 02_主图/图7图8_分图重排_20261019/02_Combined. Run Rscript draw_closeout_figures.R for Figures 4–5 and Supplementary Figure 1. Only these final figure workflows should be used for the corresponding submission figures. Figure 4 five-level priority scores and Figure 8A three-level CRC eligibility codes have different descriptive purposes; no pooled HCC eligibility row is used.

The supplied result CSVs are expected reference outputs. This attachment reproduces revision analyses from public analysis-ready/source tables; it does not claim a new FASTQ-to-result reproduction of the entire original study. Original upstream processing is documented by the archived release and the original data sources. Senlin Zhao, an author of the source study and the GEO-listed contact, confirmed to the manuscript authors on 20 October 2026 that all six analysed GCA samples (GSM7714834–GSM7714839) are human and that their correspondence to the deposited count matrix is correct. The specific human cell-line name was not supplied. Public MC38 descriptions and unresolved independent-culture metadata are recorded in R9_DataProvenance. Repository-reported reference and available replication metadata are documented in R9_DataProvenance.


## Independent scoring and global BH verification

Run `python -B 07_代码与日志/verify_ratings_and_global_BH.py` from this extracted folder. This standard-library script compares the original ratings completed by Yifei Wang with the independently completed ratings from Jiangshan Hu, and recalculates unified-partition global BH from saved raw p values. The assessments use different scales and are summarized separately. It writes `05_分析结果/independent_ratings/verification.json`.

The human-rating records were supplied/confirmed by the manuscript authors. The second-rater input preserves the supplied answers and original free-text reasons verbatim; current GCA provenance is recorded separately in the workbook and `05_分析结果/figure_source/R9_DataProvenance.csv`. No communication record or exact cell-line name is invented. Independent agreement assesses coding consistency within these six evidence objects, not biological reference-case accuracy.

`ST16d_Robustness` provides explicit availability and scope columns for mOTU. CRC-only and presence/absence support apply to all pairs; exact-taxon mOTU support applies where evaluable. P. micra is a descriptive near-neighbour for Parvimonas unclassified.

Historical fixed-family inputs and the original supplementary workbook remain labelled source references. They are not the current score authority; use the separate current Supplementary Data 1 and its R6, R9, R16, R17, and R18 tables.


## Final synchronized package, 25 October 2026
The current main-text companion workbook contains 89 data sheets, including R19_TargetPanelProvenance; it excludes the former README worksheet.
`final_consistency/verify_target_panel.py` uses only Python standard-library modules; run it from any directory. It verifies the 55-symbol intersection of the supplied archived gutMGene/SEA/STP/HCC exports and the 51-symbol expression mapping. These are archived project exports, not a target list sourced from Li et al. (2022). Original database query dates/version metadata were not retained.
`final_consistency/draw_figure3.R` reproduces Figure 3 with distinct feature-window rows; it requires ggplot2, patchwork, ragg, and svglite. Pass an output directory as the first argument. Input CSVs are supplied in the adjacent inputs folder.
`final_consistency/original_workflow_references` preserves original HCC/CRC bulk-processing and historical-target scripts as provenance references. Those original scripts use the source project directory and require its raw/expression inputs; they are not advertised as portable full raw-data workflows. The target check and Figure 3 entry points use supplied relative-path inputs.
The immutable v1.1.0 archive represents the original workflow; this supplementary attachment includes subsequent analyses and the synchronized final additions.

## One-command execution and verification

Install requirements.txt and the R dependencies listed above, then run `python -B -X utf8 run_revision.py --rscript Rscript` from the package root. Set REVISION_R_LIBRARY to one optional R library directory. `rebuild_unified_global_BH.py` regenerates the manuscript global-BH family after the historical per-taxon diagnostic outputs. Use unified_global_BH_verified.csv and global_BH_run_summary.json for the current unified-partition result. The per-taxon diagnostic outputs have their scope in their column names.

INDEPENDENT_REPRODUCTION_20261027.json records comparisons of ten regenerated key tables with the manuscript companion reference outputs and the independently checked human-rating and BH summaries. The 27 October verification used edgeR 4.10.7 and limma 3.68.5; the earlier reference execution used edgeR 4.10.6 and limma 3.68.5. Numerical comparisons passed with relative tolerance 1e-8 and absolute tolerance 1e-11. The historical tested_analysis_versions.json is retained as an original execution record.
