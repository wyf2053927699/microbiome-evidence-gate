source(file.path(Sys.getenv("HCC_REBUILD_ROOT"), "04_workflows", "00_config.R"))

if (!requireNamespace("data.table", quietly = TRUE)) stop("data.table is required.")
if (!requireNamespace("DESeq2", quietly = TRUE)) stop("DESeq2 is required.")

data_root <- Sys.getenv(
  "PRJEB54571_DATA_ROOT",
  unset = file.path(dir_map$raw, "public_code", "HCC_microbiota2022", "data")
)
meta <- utils::read.csv(
  file.path(data_root, "rnaseq", "sample_information_edit.csv"),
  stringsAsFactors = FALSE, check.names = FALSE
)
counts_df <- data.table::fread(
  file.path(data_root, "rnaseq", "salmon.merged.gene_counts.tsv"),
  sep = "\t", header = TRUE, data.table = FALSE
)

# Salmon column names replace '-S1' with '.L1' in the merged count table.
meta$count_column <- sub("-S1$", ".L1", meta$name)
stopifnot(all(meta$count_column %in% names(counts_df)))

count_matrix <- as.matrix(counts_df[, meta$count_column, drop = FALSE])
storage.mode(count_matrix) <- "numeric"
count_matrix <- round(count_matrix)
rownames(count_matrix) <- sub("\\.[0-9]+$", "", counts_df$gene_id)
colnames(count_matrix) <- meta$name

gene_symbol <- counts_df$gene_name
names(gene_symbol) <- rownames(count_matrix)

analysis_keep <- meta$Condition %in% c("HCC", "Cirrhosis")
meta2 <- meta[analysis_keep, , drop = FALSE]
count_matrix <- count_matrix[, meta2$name, drop = FALSE]
meta2$Condition <- stats::relevel(factor(meta2$Condition), ref = "Cirrhosis")
meta2$sex <- factor(meta2$sex)
meta2$age_z <- as.numeric(scale(meta2$age))
rownames(meta2) <- meta2$name

keep_gene <- rowSums(count_matrix >= 10) >= 5
filter_audit <- data.frame(
  metric = c("input genes", "genes retained (count >=10 in >=5 samples)", "HCC samples", "cirrhosis samples"),
  value = c(nrow(count_matrix), sum(keep_gene), sum(meta2$Condition == "HCC"), sum(meta2$Condition == "Cirrhosis")),
  stringsAsFactors = FALSE
)
write_csv_base(filter_audit, file.path(dir_map$audit, "prjeb54571_rnaseq_filter_audit.csv"))

# Primary model is condition-only because the comparator group has only five
# patients. The age/sex model is retained as a sensitivity analysis, not used
# to rescue features that fail the primary multiplicity correction.
dds_primary <- DESeq2::DESeqDataSetFromMatrix(
  countData = count_matrix[keep_gene, , drop = FALSE],
  colData = meta2,
  design = ~ Condition
)
dds_primary <- DESeq2::DESeq(dds_primary, quiet = TRUE)
res_primary <- as.data.frame(DESeq2::results(dds_primary, contrast = c("Condition", "HCC", "Cirrhosis")))

dds_adjusted <- DESeq2::DESeqDataSetFromMatrix(
  countData = count_matrix[keep_gene, , drop = FALSE],
  colData = meta2,
  design = ~ age_z + sex + Condition
)
dds_adjusted <- DESeq2::DESeq(dds_adjusted, quiet = TRUE)
res_adjusted <- as.data.frame(DESeq2::results(dds_adjusted, contrast = c("Condition", "HCC", "Cirrhosis")))

result <- data.frame(
  ensembl_gene_id = rownames(res_primary),
  gene_symbol = unname(gene_symbol[rownames(res_primary)]),
  baseMean = res_primary$baseMean,
  log2FoldChange = res_primary$log2FoldChange,
  lfcSE = res_primary$lfcSE,
  stat = res_primary$stat,
  pvalue = res_primary$pvalue,
  padj_BH = res_primary$padj,
  adjusted_log2FoldChange = res_adjusted$log2FoldChange,
  adjusted_pvalue = res_adjusted$pvalue,
  adjusted_padj_BH = res_adjusted$padj,
  stringsAsFactors = FALSE
)
result$direction_concordant <- sign(result$log2FoldChange) == sign(result$adjusted_log2FoldChange)
result$primary_DE <- !is.na(result$padj_BH) & result$padj_BH < 0.05 & abs(result$log2FoldChange) >= 1
result <- result[order(result$padj_BH, -abs(result$log2FoldChange), na.last = TRUE), ]
write_csv_base(result, file.path(dir_map$results, "prjeb54571_host_rnaseq_deseq2.csv"))

vsd <- DESeq2::vst(dds_primary, blind = FALSE)
vst_matrix <- SummarizedExperiment::assay(vsd)
write_csv_base(
  data.frame(ensembl_gene_id = rownames(vst_matrix), gene_symbol = unname(gene_symbol[rownames(vst_matrix)]), vst_matrix, check.names = FALSE),
  file.path(dir_map$intermediate, "prjeb54571_host_rnaseq_vst.csv")
)

# Evaluate, but do not privilege, the historical 55-target list.
candidate <- utils::read.csv(
  file.path(dir_map$intermediate, "candidate_targets_hgnc_corrected.csv"),
  stringsAsFactors = FALSE
)
candidate_result <- result[toupper(result$gene_symbol) %in% toupper(candidate$Gene), , drop = FALSE]
candidate_result$historical_candidate <- TRUE
write_csv_base(candidate_result, file.path(dir_map$results, "prjeb54571_host_rnaseq_historical_target_overlap.csv"))

summary <- data.frame(
  metric = c(
    "tested genes", "primary DE genes", "upregulated DE genes", "downregulated DE genes",
    "historical candidate genes measured", "historical candidates passing primary DE"
  ),
  value = c(
    nrow(result), sum(result$primary_DE),
    sum(result$primary_DE & result$log2FoldChange > 0),
    sum(result$primary_DE & result$log2FoldChange < 0),
    nrow(candidate_result), sum(candidate_result$primary_DE)
  ),
  stringsAsFactors = FALSE
)
write_csv_base(summary, file.path(dir_map$results, "prjeb54571_host_rnaseq_summary.csv"))

message("Host RNA-seq analysis completed: ", sum(result$primary_DE),
        " genes passed padj < 0.05 and |log2FC| >= 1; historical targets were evaluated without selection privilege.")
