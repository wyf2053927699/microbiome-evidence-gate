#!/usr/bin/env Rscript

# Independent HCC-versus-cirrhosis validation in GSE63898 (GPL13667).
# The primary family is frozen from the PRJEB54571 GO-BP discovery analysis.
# Axis-oriented modules are a separate, prespecified sensitivity family copied
# from 23_analyse_gse149614_donor_paired_programs.py. No GSE63898 result is used
# to select a programme, gene or probe.

options(stringsAsFactors = FALSE)

root <- Sys.getenv("HCC_REBUILD_ROOT", unset = "X:/")
raw_dir <- file.path(root, "02_raw", "GSE63898")
out_dir <- file.path(root, "06_results", "GSE63898", "host_programs")
audit_dir <- file.path(root, "09_audit")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(audit_dir, recursive = TRUE, showWarnings = FALSE)

matrix_file <- file.path(raw_dir, "GSE63898_series_matrix.txt.gz")
platform_file <- file.path(raw_dir, "GPL13667_platform_full.soft.txt")
probe_annotation_file <- file.path(root, "03_metadata", "GSE63898", "hgu219_probe_symbol_mapping.csv")
go_annotation_file <- file.path(root, "03_metadata", "GSE63898", "human_go_bp_mapping.csv")
stopifnot(file.exists(matrix_file), file.exists(platform_file),
          file.exists(probe_annotation_file), file.exists(go_annotation_file))

message("Reading series matrix ...")
expr <- read.delim(
  gzfile(matrix_file), header = TRUE, comment.char = "!", quote = "\"",
  check.names = FALSE, row.names = 1
)
expr <- as.matrix(expr)
storage.mode(expr) <- "numeric"

message("Reading sample metadata ...")
con <- gzfile(matrix_file, open = "rt")
on.exit(close(con), add = TRUE)
meta_lines <- character()
repeat {
  line <- readLines(con, n = 1, warn = FALSE)
  if (!length(line) || identical(line, "!series_matrix_table_begin")) break
  if (grepl("^!Sample_(title|geo_accession|characteristics_ch1)", line)) {
    meta_lines <- c(meta_lines, line)
  }
}
close(con)
on.exit(NULL, add = FALSE)

split_geo_line <- function(line) {
  x <- strsplit(line, "\t", fixed = TRUE)[[1]][-1]
  gsub('^"|"$', "", x)
}
title_line <- meta_lines[grepl("^!Sample_title\t", meta_lines)][1]
geo_line <- meta_lines[grepl("^!Sample_geo_accession\t", meta_lines)][1]
titles <- split_geo_line(title_line)
geo <- split_geo_line(geo_line)
if (length(geo) != ncol(expr) || !identical(geo, colnames(expr))) {
  stop("Series-matrix sample order does not match GEO accessions")
}
group <- ifelse(
  grepl("^hepatocellular carcinoma", titles, ignore.case = TRUE), "HCC",
  ifelse(grepl("^cirrhosis", titles, ignore.case = TRUE), "Cirrhosis", NA_character_)
)
if (anyNA(group)) stop("Unresolved GSE63898 disease labels")
plate <- sub("^.*\\[", "", titles)
plate <- sub("\\]$", "", plate)
plate <- sub("^[^_]+_", "", plate)
plate <- sub("_[A-H][0-9]+(_[0-9]+)?$", "", plate)
plate <- gsub("placa", "plate", plate, fixed = TRUE)
plate <- gsub("[ _-]+", "_", plate)
samples <- data.frame(
  sample_id = geo, title = titles, group = factor(group, levels = c("Cirrhosis", "HCC")),
  processing_plate = factor(plate), stringsAsFactors = FALSE
)
if (!identical(as.integer(table(samples$group)), c(168L, 228L))) {
  stop("Expected 168 cirrhosis and 228 HCC samples")
}

message("Reading Bioconductor hgu219.db and org.Hs.eg.db exports ...")
ann <- read.csv(probe_annotation_file, check.names = FALSE)
go_map <- read.csv(go_annotation_file, check.names = FALSE)
probe_match <- match(rownames(expr), ann$probe_id)
mapped <- !is.na(probe_match)
write.csv(
  data.frame(probe_id = rownames(expr)[!mapped]),
  file.path(audit_dir, "GSE63898_unmapped_series_matrix_probes.csv"), row.names = FALSE
)
if (mean(mapped) < 0.95) {
  stop("Official platform annotation maps only ", round(100 * mean(mapped), 2), "% of expression probes")
}
message("Official annotation mapping: ", sum(mapped), "/", length(mapped),
        " probes (", round(100 * mean(mapped), 2), "%)")
expr <- expr[mapped, , drop = FALSE]
ann <- ann[probe_match[mapped], , drop = FALSE]

# Retain only unambiguous single-symbol mappings. Multiple probes per symbol are
# collapsed by the per-sample median, avoiding significance-based probe choice.
symbol <- trimws(ann$gene_symbol)
symbol[symbol %in% c("", "---")] <- NA_character_
valid_symbol <- !is.na(symbol) & ann$is_multiple == 0 & grepl("^[A-Za-z0-9.-]+$", symbol)
symbol_levels <- unique(symbol[valid_symbol])
message("Collapsing ", sum(valid_symbol), " probes to ", length(symbol_levels), " genes ...")
gene_expr <- vapply(symbol_levels, function(g) {
  idx <- which(valid_symbol & symbol == g)
  if (length(idx) == 1L) expr[idx, ] else apply(expr[idx, , drop = FALSE], 2, median, na.rm = TRUE)
}, numeric(ncol(expr)))
gene_expr <- t(gene_expr)
rownames(gene_expr) <- symbol_levels
colnames(gene_expr) <- colnames(expr)

go_programs <- c(
  cell_division = "GO:0051301",
  ribosome_biogenesis = "GO:0042254",
  type_I_interferon_response = "GO:0071357",
  respiratory_electron_transport_chain = "GO:0022904"
)
go_members <- lapply(go_programs, function(go_id) {
  unique(go_map$gene_symbol[go_map$go_id == go_id])
})

axis_programs <- list(
  hepatocyte_bile_acid_synthesis_transport = c(
    "CYP7A1", "CYP8B1", "CYP27A1", "CYP7B1", "BAAT", "SLC10A1",
    "ABCB11", "ABCC2", "ABCC3", "SLC51A", "SLC51B", "NR1H4"
  ),
  bile_acid_receptor_response = c("NR1H4", "GPBAR1", "FGF19", "KLB", "FGFR4", "NR0B2"),
  ahr_aromatic_response = c("AHR", "ARNT", "AHRR", "CYP1A1", "CYP1B1", "IDO1", "TDO2", "IL22"),
  choline_phospholipid_metabolism = c(
    "CHKA", "CHKB", "PCYT1A", "PCYT1B", "PEMT", "PNPLA7", "GPCPD1",
    "LPCAT1", "LPCAT2", "SLC44A1", "PLA2G6"
  ),
  type_i_interferon_fixed = c(
    "STAT1", "STAT2", "IRF7", "ISG15", "IFIT1", "IFIT2", "IFIT3",
    "MX1", "OAS1", "OAS2", "IFI6", "IFI27"
  ),
  cell_cycle_fixed = c("MKI67", "PCNA", "TOP2A", "CDK1", "CCNB1", "CCNB2", "BUB1", "AURKB")
)

hedges_g <- function(x_hcc, x_cirr) {
  n1 <- length(x_hcc); n0 <- length(x_cirr)
  sp <- sqrt(((n1 - 1) * var(x_hcc) + (n0 - 1) * var(x_cirr)) / (n1 + n0 - 2))
  d <- (mean(x_hcc) - mean(x_cirr)) / sp
  correction <- 1 - 3 / (4 * (n1 + n0) - 9)
  g <- correction * d
  se <- sqrt((n1 + n0) / (n1 * n0) + g^2 / (2 * (n1 + n0 - 2)))
  c(g = g, ci_low = g - 1.96 * se, ci_high = g + 1.96 * se)
}

score_program <- function(genes) {
  detected <- intersect(unique(genes), rownames(gene_expr))
  if (length(detected) < 3L) return(list(score = NULL, genes = detected))
  x <- gene_expr[detected, , drop = FALSE]
  z <- t(scale(t(x)))
  z[!is.finite(z)] <- 0
  list(score = colMeans(z), genes = detected)
}

test_family <- function(programs, family_name) {
  stats_rows <- list(); score_rows <- list(); detected_rows <- list()
  for (nm in names(programs)) {
    scored <- score_program(programs[[nm]])
    detected_rows[[nm]] <- data.frame(
      family = family_name, program = nm, gene = programs[[nm]],
      detected = programs[[nm]] %in% scored$genes
    )
    if (is.null(scored$score)) next
    frame <- samples
    frame$score <- unname(scored$score[frame$sample_id])
    frame$program <- nm
    frame$family <- family_name
    score_rows[[nm]] <- frame
    hcc <- frame$score[frame$group == "HCC"]
    cirr <- frame$score[frame$group == "Cirrhosis"]
    tt <- t.test(hcc, cirr)
    fit <- lm(score ~ group + processing_plate, data = frame)
    co <- summary(fit)$coefficients
    adj_row <- co["groupHCC", ]
    ci <- confint(fit, "groupHCC", level = 0.95)[1, ]
    hg <- hedges_g(hcc, cirr)
    stats_rows[[nm]] <- data.frame(
      family = family_name, program = nm,
      requested_genes = length(unique(programs[[nm]])), detected_genes = length(scored$genes),
      detected_gene_symbols = paste(scored$genes, collapse = ";"),
      n_hcc = length(hcc), n_cirrhosis = length(cirr),
      mean_hcc = mean(hcc), mean_cirrhosis = mean(cirr),
      unadjusted_mean_difference = mean(hcc) - mean(cirr),
      hedges_g = hg[["g"]], hedges_g_ci_low = hg[["ci_low"]], hedges_g_ci_high = hg[["ci_high"]],
      welch_p = tt$p.value,
      plate_adjusted_beta = adj_row[["Estimate"]], plate_adjusted_se = adj_row[["Std. Error"]],
      plate_adjusted_ci_low = ci[[1]], plate_adjusted_ci_high = ci[[2]],
      plate_adjusted_p = adj_row[["Pr(>|t|)"]]
    )
  }
  stats_tab <- do.call(rbind, stats_rows)
  stats_tab$welch_q_within_family <- p.adjust(stats_tab$welch_p, method = "BH")
  stats_tab$plate_adjusted_q_within_family <- p.adjust(stats_tab$plate_adjusted_p, method = "BH")
  list(
    stats = stats_tab,
    scores = do.call(rbind, score_rows),
    detected = do.call(rbind, detected_rows)
  )
}

primary <- test_family(go_members, "primary_PRJEB54571_GO_programs")
axis <- test_family(axis_programs, "prespecified_axis_sensitivity")
program_stats <- rbind(primary$stats, axis$stats)
program_scores <- rbind(primary$scores, axis$scores)
gene_detection <- rbind(primary$detected, axis$detected)

# Import the already-frozen PRJEB54571 discovery direction and TCGA paired
# result. Significance in GSE63898 alone is not labelled replication.
prior_file <- file.path(root, "06_results", "tcga_lihc_host_program_paired_validation.csv")
prior <- read.csv(prior_file, check.names = FALSE)
idx_primary <- program_stats$family == "primary_PRJEB54571_GO_programs"
prior_idx <- match(program_stats$program[idx_primary], prior$module)
program_stats$discovery_NES <- NA_real_
program_stats$discovery_q_value <- NA_real_
program_stats$tcga_median_paired_difference <- NA_real_
program_stats$tcga_q_value_BH <- NA_real_
program_stats$direction_concordant_with_PRJEB54571 <- NA
program_stats$direction_concordant_with_TCGA <- NA
program_stats$strict_three_dataset_replication <- NA
program_stats$discovery_NES[idx_primary] <- prior$discovery_NES[prior_idx]
program_stats$discovery_q_value[idx_primary] <- prior$discovery_q_value[prior_idx]
program_stats$tcga_median_paired_difference[idx_primary] <- prior$median_paired_difference[prior_idx]
program_stats$tcga_q_value_BH[idx_primary] <- prior$q_value_BH[prior_idx]
program_stats$direction_concordant_with_PRJEB54571[idx_primary] <-
  sign(program_stats$plate_adjusted_beta[idx_primary]) == sign(prior$discovery_NES[prior_idx])
program_stats$direction_concordant_with_TCGA[idx_primary] <-
  sign(program_stats$plate_adjusted_beta[idx_primary]) == sign(prior$median_paired_difference[prior_idx])
program_stats$strict_three_dataset_replication[idx_primary] <-
  program_stats$plate_adjusted_q_within_family[idx_primary] < 0.05 &
  prior$discovery_q_value[prior_idx] < 0.05 & prior$q_value_BH[prior_idx] < 0.05 &
  program_stats$direction_concordant_with_PRJEB54571[idx_primary] &
  program_stats$direction_concordant_with_TCGA[idx_primary]

# Gene-level effects are reported for the union of programme members, without
# gene-level selection. BH adjustment is applied across that frozen union.
test_genes <- sort(unique(gene_detection$gene[gene_detection$detected]))
gene_rows <- lapply(test_genes, function(g) {
  frame <- samples
  frame$expression <- gene_expr[g, frame$sample_id]
  hcc <- frame$expression[frame$group == "HCC"]
  cirr <- frame$expression[frame$group == "Cirrhosis"]
  fit <- lm(expression ~ group + processing_plate, data = frame)
  co <- summary(fit)$coefficients["groupHCC", ]
  data.frame(
    gene = g, mean_hcc = mean(hcc), mean_cirrhosis = mean(cirr),
    mean_difference = mean(hcc) - mean(cirr), welch_p = t.test(hcc, cirr)$p.value,
    plate_adjusted_beta = co[["Estimate"]], plate_adjusted_se = co[["Std. Error"]],
    plate_adjusted_p = co[["Pr(>|t|)"]]
  )
})
gene_stats <- do.call(rbind, gene_rows)
gene_stats$welch_q_union <- p.adjust(gene_stats$welch_p, method = "BH")
gene_stats$plate_adjusted_q_union <- p.adjust(gene_stats$plate_adjusted_p, method = "BH")

write.csv(samples, file.path(out_dir, "gse63898_sample_manifest.csv"), row.names = FALSE)
write.csv(program_stats, file.path(out_dir, "gse63898_program_validation.csv"), row.names = FALSE)
write.csv(program_scores, file.path(out_dir, "gse63898_program_scores.csv"), row.names = FALSE)
write.csv(gene_detection, file.path(out_dir, "gse63898_program_gene_detection.csv"), row.names = FALSE)
write.csv(gene_stats, file.path(out_dir, "gse63898_prespecified_gene_results.csv"), row.names = FALSE)

summary_lines <- c(
  "GSE63898 independent host-program validation",
  paste0("Expression probes: ", nrow(expr)),
  paste0("Samples: ", ncol(expr), " (HCC=", sum(samples$group == "HCC"),
         ", cirrhosis=", sum(samples$group == "Cirrhosis"), ")"),
  paste0("Unambiguous genes after median probe collapse: ", nrow(gene_expr)),
  paste0("Processing-plate levels: ", nlevels(samples$processing_plate)),
  paste0("Primary programmes with plate-adjusted BH q<0.05: ",
         sum(primary$stats$plate_adjusted_q_within_family < 0.05), "/", nrow(primary$stats)),
  paste0("Primary programmes meeting strict three-dataset directional replication: ",
         sum(program_stats$strict_three_dataset_replication %in% TRUE), "/", sum(idx_primary)),
  paste0("Axis-sensitivity programmes with plate-adjusted BH q<0.05: ",
         sum(axis$stats$plate_adjusted_q_within_family < 0.05), "/", nrow(axis$stats)),
  "Contrast: primary HCC tissue versus non-tumour cirrhotic tissue.",
  "Interpretation boundary: this bulk-tissue contrast validates host programmes; it does not establish microbial causality."
)
writeLines(summary_lines, file.path(out_dir, "gse63898_validation_summary.txt"))

message(paste(summary_lines, collapse = "\n"))
