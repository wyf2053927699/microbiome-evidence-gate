source(file.path(Sys.getenv("HCC_REBUILD_ROOT"), "04_workflows", "00_config.R"))

read_gene_file <- function(path) {
  x <- utils::read.csv(path, check.names = FALSE, stringsAsFactors = FALSE)
  assert_columns(x, "Gene", basename(path))
  clean_gene_symbols(x$Gene)
}

result1 <- file.path(legacy_root, "Result1_target_identification")

paths <- c(
  gutmgene_human = file.path(result1, "gutMGene_human_targets.csv"),
  sea = file.path(result1, "SEA_targets.csv"),
  stp = file.path(result1, "STP_targets.csv"),
  hcc = file.path(result1, "HCC_targets_GeneCards_OMIM.csv"),
  legacy54 = file.path(result1, "final_54_targets.csv"),
  current55 = file.path(result1, "03_final_candidate_targets.csv")
)

stopifnot(all(file.exists(paths)))
sets <- lapply(paths, read_gene_file)

recomputed <- list(
  sea_stp_intersection = intersect(sets$sea, sets$stp),
  metabolite_hcc_intersection = intersect(intersect(sets$sea, sets$stp), sets$hcc),
  final_intersection = Reduce(intersect, list(sets$sea, sets$stp, sets$hcc, sets$gutmgene_human))
)

summary_table <- data.frame(
  object = c(names(sets), names(recomputed)),
  n_unique = c(vapply(sets, length, integer(1)), vapply(recomputed, length, integer(1)))
)

comparison_table <- data.frame(
  comparison = c(
    "recomputed_final_not_current55",
    "current55_not_recomputed_final",
    "current55_not_legacy54",
    "legacy54_not_current55"
  ),
  genes = c(
    paste(setdiff(recomputed$final_intersection, sets$current55), collapse = ";"),
    paste(setdiff(sets$current55, recomputed$final_intersection), collapse = ";"),
    paste(setdiff(sets$current55, sets$legacy54), collapse = ";"),
    paste(setdiff(sets$legacy54, sets$current55), collapse = ";")
  )
)

quality_table <- do.call(
  rbind,
  lapply(names(paths), function(nm) {
    raw <- utils::read.csv(paths[[nm]], check.names = FALSE, stringsAsFactors = FALSE)
    data.frame(
      object = nm,
      raw_rows = nrow(raw),
      unique_clean_genes = length(sets[[nm]]),
      duplicate_or_invalid_rows = nrow(raw) - length(sets[[nm]])
    )
  })
)

write_csv_base(summary_table, file.path(dir_map$audit, "legacy_target_set_counts.csv"))
write_csv_base(comparison_table, file.path(dir_map$audit, "legacy_target_set_differences.csv"))
write_csv_base(quality_table, file.path(dir_map$audit, "legacy_target_file_quality.csv"))
write_csv_base(
  data.frame(Gene = recomputed$final_intersection),
  file.path(dir_map$intermediate, "candidate_targets_recomputed.csv")
)

if (!identical(recomputed$final_intersection, sets$current55)) {
  stop("Recomputed final target set does not exactly match the current 55-target file. See audit output.")
}

message("Legacy target audit passed: recomputed final set exactly matches current55.")

