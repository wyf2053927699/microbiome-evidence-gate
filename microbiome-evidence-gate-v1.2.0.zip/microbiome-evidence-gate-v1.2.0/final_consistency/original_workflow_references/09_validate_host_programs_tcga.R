source(file.path(Sys.getenv("HCC_REBUILD_ROOT"), "04_workflows", "00_config.R"))

if (!requireNamespace("data.table", quietly = TRUE)) stop("data.table is required.")
if (!requireNamespace("AnnotationDbi", quietly = TRUE) ||
    !requireNamespace("org.Hs.eg.db", quietly = TRUE)) stop("Annotation packages are required.")

tcga_root <- Sys.getenv("TCGA_LIHC_DATA_ROOT")
if (!nzchar(tcga_root)) stop("TCGA_LIHC_DATA_ROOT must point to an ASCII-readable cache.")

expr <- data.table::fread(
  file.path(tcga_root, "TCGA_LIHC_log2TPM_expression_geneSymbol.csv"),
  data.table = FALSE, check.names = FALSE
)
ann <- utils::read.csv(
  file.path(tcga_root, "TCGA_LIHC_sample_annotation.csv"),
  stringsAsFactors = FALSE, check.names = FALSE
)
names(expr)[1] <- "Gene"

go_ids <- c(
  cell_division = "GO:0051301",
  ribosome_biogenesis = "GO:0042254",
  type_I_interferon_response = "GO:0071357",
  respiratory_electron_transport_chain = "GO:0022904"
)

all_symbols <- unique(expr$Gene)
go_map <- AnnotationDbi::select(
  org.Hs.eg.db::org.Hs.eg.db,
  keys = all_symbols, keytype = "SYMBOL", columns = c("GO", "ONTOLOGY")
)
go_map <- go_map[go_map$GO %in% go_ids & go_map$ONTOLOGY == "BP", , drop = FALSE]

sample_ids <- intersect(names(expr), ann$sample_id)
ann2 <- ann[match(sample_ids, ann$sample_id), , drop = FALSE]
pairable_patients <- intersect(
  ann2$patient_id[ann2$group == "Tumor"],
  ann2$patient_id[ann2$group == "Normal"]
)

module_scores <- list()
module_stats <- list()
for (module in names(go_ids)) {
  genes <- unique(go_map$SYMBOL[go_map$GO == go_ids[[module]]])
  genes <- intersect(genes, expr$Gene)
  x <- as.matrix(expr[match(genes, expr$Gene), sample_ids, drop = FALSE])
  storage.mode(x) <- "numeric"
  z <- t(scale(t(x)))
  z[!is.finite(z)] <- NA_real_
  score <- colMeans(z, na.rm = TRUE)
  tab <- data.frame(
    sample_id = names(score), patient_id = ann2$patient_id,
    group = ann2$group, module = module, score = unname(score),
    n_genes = length(genes), stringsAsFactors = FALSE
  )
  module_scores[[module]] <- tab

  paired <- tab[tab$patient_id %in% pairable_patients & tab$group %in% c("Tumor", "Normal"), ]
  wide <- reshape(paired[, c("patient_id", "group", "score")], idvar = "patient_id", timevar = "group", direction = "wide")
  wide <- wide[stats::complete.cases(wide), ]
  wt <- stats::wilcox.test(wide$score.Tumor, wide$score.Normal, paired = TRUE, exact = FALSE)
  module_stats[[module]] <- data.frame(
    module = module, GO_ID = go_ids[[module]], n_genes = length(genes),
    n_pairs = nrow(wide), median_paired_difference = median(wide$score.Tumor - wide$score.Normal),
    wilcoxon_V = unname(wt$statistic), p_value = wt$p.value,
    discovery_NES = NA_real_, discovery_q_value = NA_real_,
    stringsAsFactors = FALSE
  )
}

score_table <- do.call(rbind, module_scores)
stats_table <- do.call(rbind, module_stats)
gsea <- utils::read.csv(file.path(dir_map$results, "prjeb54571_host_go_bp_gsea.csv"), stringsAsFactors = FALSE)
idx <- match(stats_table$GO_ID, gsea$pathway)
stats_table$discovery_NES <- gsea$NES[idx]
stats_table$discovery_q_value <- gsea$padj[idx]
stats_table$direction_concordant <- sign(stats_table$median_paired_difference) == sign(stats_table$discovery_NES)
stats_table$q_value_BH <- p.adjust(stats_table$p_value, method = "BH")

write_csv_base(score_table, file.path(dir_map$results, "tcga_lihc_host_program_scores.csv"))
write_csv_base(stats_table, file.path(dir_map$results, "tcga_lihc_host_program_paired_validation.csv"))

message("TCGA paired validation completed: ", sum(stats_table$q_value_BH < 0.05 & stats_table$direction_concordant),
        "/", nrow(stats_table), " host programs validated with concordant direction.")
