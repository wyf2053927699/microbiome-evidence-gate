from pathlib import Path
import csv, hashlib, json
p=Path(__file__).resolve().parent/'inputs'
names=['gutMGene_human_targets.csv','SEA_targets.csv','STP_targets.csv','HCC_targets_GeneCards_OMIM.csv']
def load(n):
    with (p/n).open(encoding='utf-8-sig') as f:return {r['Gene'].strip().upper() for r in csv.DictReader(f) if r['Gene'].strip()}
panel=set.intersection(*(load(n) for n in names))
assert panel==load('03_final_candidate_targets.csv') and len(panel)==55
with (p/'prjeb54571_host_rnaseq_historical_target_overlap.csv').open(encoding='utf-8-sig') as f:mapped={r['gene_symbol'] for r in csv.DictReader(f)}
assert len(mapped)==51 and mapped<=panel
print(json.dumps({'intersection':len(panel),'mapped':len(mapped),'not_mapped':sorted(panel-mapped)},indent=2))
