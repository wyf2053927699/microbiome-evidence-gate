# Evidence-gate comparative stress test

This directory compares permissive evidence-selection rules with the exact non-compensatory rule. Synthetic broken-link controls provide structural truth only: an axis with one essential link set to zero must not be promoted. The outputs do not estimate clinical accuracy, causality, or the biological truth of an HCC mechanism.
