from pathlib import Path
import sys,json,hashlib
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(Path(__file__).resolve().parent/'python_deps'))
import numpy as np,pandas as pd
from scipy.stats import rankdata,norm,pearsonr,mannwhitneyu,t
from scipy.linalg import qr
I=ROOT/'06_输入与依据';O=ROOT/'05_分析结果/02_CRC统一分区分析'
LOCKED=['Peptostreptococcus stomatis','Gemella morbillorum','Fusobacterium nucleatum','Parvimonas unclassified']
TARGET='Peptostreptococcus stomatis';MET='C01921_Glycocholate'
COV=['Group','Age','Gender','BMI','Brinkman Index','Alcohol','Tumor location']
NUM=['Age','BMI','Brinkman Index','Alcohol'];CRC={'Stage_0','Stage_I_II','Stage_III_IV'}
SEED=20261018
def bh(p):
 p=np.asarray(p,float);q=np.full(len(p),np.nan);ok=np.isfinite(p);v=p[ok];ix=np.argsort(v);a=np.minimum.accumulate((v[ix]*len(v)/np.arange(1,len(v)+1))[::-1])[::-1];r=np.empty(len(v));r[ix]=np.minimum(a,1);q[ok]=r;return q
def invnorm(x):
 x=np.asarray(x,float);ok=np.isfinite(x);v=np.full(len(x),np.nan);v[ok]=norm.ppf((rankdata(x[ok],method='average')-.5)/ok.sum());return v
def rint_frame(df):return pd.DataFrame({c:invnorm(df[c]) for c in df},index=df.index)
def design(c,mode):
 if mode=='legacy':
  x=pd.get_dummies(c[COV],drop_first=True,dtype=float).apply(pd.to_numeric,errors='coerce')
  x=x[[k for k in x if x[k].notna().sum()>=max(10,int(.8*len(x))) and x[k].nunique(dropna=True)>1]]
 else:
  x=c[COV].copy()
  for k in NUM:x[k]=pd.to_numeric(x[k],errors='coerce')
  x=pd.get_dummies(x,columns=[k for k in COV if k not in NUM],drop_first=True,dtype=float)
  x=x[[k for k in x if x[k].nunique(dropna=True)>1]]
 ok=x.notna().all(axis=1)
 d=np.column_stack([np.ones(ok.sum()),x.loc[ok].to_numpy(float)]);names=['Intercept']+list(x.columns)
 if mode!='legacy':
  rank=np.linalg.matrix_rank(d)
  _,_,pivot=qr(d,mode='economic',pivoting=True)
  chosen=sorted(pivot[:rank]);d=d[:,chosen];names=[names[k] for k in chosen]
 return x,ok,d,names
def associate(c,s,m,mode):
 x,valid,D,names=design(c,mode);s=rint_frame(s);m=rint_frame(m)
 # All source profiles are finite; retain explicit sample checks rather than silently imputing.
 assert np.isfinite(s.to_numpy()).all() and np.isfinite(m.to_numpy()).all()
 X=s.loc[valid].to_numpy();Y=m.loc[valid].to_numpy();X=X-D@np.linalg.lstsq(D,X,rcond=None)[0];Y=Y-D@np.linalg.lstsq(D,Y,rcond=None)[0]
 rank=int(np.linalg.matrix_rank(D));n=len(X);df=n-rank-1
 rows=[]
 for j,sp in enumerate(s.columns):
  for k,mt in enumerate(m.columns):
   r,pold=pearsonr(X[:,j],Y[:,k]);stat=r*np.sqrt(df/max(1e-15,1-r*r));p=2*t.sf(abs(stat),df)
   se=1/np.sqrt(n-(rank-1)-3) if n-(rank-1)>3 else np.nan;z=np.arctanh(np.clip(r,-.999999999,.999999999));lo,hi=np.tanh([z-1.95996398454*se,z+1.95996398454*se])
   rows.append({'species':sp,'metabolite':mt,'n':n,'design_rank_including_intercept':rank,'partial_correlation_df':df,'r':r,'p_legacy_n_minus_2':pold,'p':p,'ci_low_fisher':lo,'ci_high_fisher':hi})
 audit={'covariate_mode':mode,'n_partition':len(c),'n_complete':n,'excluded_ids':c.index[~valid].tolist(),'design_columns':names,'design_rank':rank}
 return pd.DataFrame(rows),audit
clinical=pd.read_csv(I/'input_clinical.csv',dtype={'subject_id':str}).set_index('subject_id')
clinical_legacy=pd.read_pickle(I/'input_clinical_original_dtypes.pkl')
S=pd.read_csv(I/'input_species.csv',dtype={'subject_id':str}).set_index('subject_id')
M=pd.read_csv(I/'input_metabolites.csv',dtype={'subject_id':str}).set_index('subject_id')
oldman=pd.read_csv(I/'ST16a_CRCManifest.csv',dtype={'subject_id':str}).set_index('subject_id')
disease=pd.read_csv(I/'ST14a_CRCManifest.csv',dtype={'Subject_ID':str}).set_index('Subject_ID')
ids=oldman.index.tolist();clinical=clinical.loc[ids];S=S.loc[ids];M=M.loc[ids]
assert len(ids)==347 and not S.index.duplicated().any()
fullpc=float(S.to_numpy()[S.to_numpy()>0].min()/2);logs=np.log(S+fullpc);oldclr=logs.sub(logs.mean(axis=1),axis=0)
oldfilter=(M.loc[oldman.partition.eq('discovery')].fillna(0).ne(0).mean()>=.2)&(M.loc[oldman.partition.eq('discovery')].nunique()>2)
oldmets=M.columns[oldfilter].tolist();print('Legacy metabolites',len(oldmets),flush=True)
parts={};audits=[]
for part in ['discovery','validation']:
 ix=oldman.index[oldman.partition.eq(part)];res,a=associate(clinical_legacy.loc[ix],oldclr.loc[ix,LOCKED],M.loc[ix,oldmets],'legacy');parts[part]=res;audits.append(dict(analysis='original_reproduction',partition=part,**a))
disc=parts['discovery'];val=parts['validation'];disc['q_global_legacy']=bh(disc.p_legacy_n_minus_2);disc['q_per_taxon_legacy']=disc.groupby('species').p_legacy_n_minus_2.transform(lambda v:bh(v))
submitted=pd.read_csv(I/'ST16b_PairedAllTests.csv');compare=disc.merge(submitted,on=['species','metabolite'],suffixes=('','_submitted'))
checks={'n_pairs':len(compare),'max_abs_r_error':float((compare.r-compare.partial_spearman_discovery).abs().max()),'max_abs_p_error':float((compare.p_legacy_n_minus_2-compare.p_discovery).abs().max()),'max_abs_q_global_error':float((compare.q_global_legacy-compare.q_bh_family).abs().max()),'max_abs_q_per_taxon_error':float((compare.q_per_taxon_legacy-compare.q_bh_family).abs().max())}
# Determine which documented family reproduces the submitted table, never choose by favourable result.
global_match=checks['max_abs_q_global_error']<1e-8;taxon_match=checks['max_abs_q_per_taxon_error']<1e-8
checks['submitted_BH_family_matching_global']=global_match;checks['submitted_BH_family_matching_per_taxon']=taxon_match
orig_candidates=disc.loc[disc.q_global_legacy<.10] if global_match else disc.loc[disc.q_per_taxon_legacy<.10]
vv=val.merge(orig_candidates[['species','metabolite']],on=['species','metabolite']);vv['q_global_legacy']=bh(vv.p_legacy_n_minus_2);vv['q_per_taxon_legacy']=vv.groupby('species').p_legacy_n_minus_2.transform(lambda v:bh(v))
vcomp=vv.merge(submitted[['species','metabolite','partial_spearman_validation','p_validation','q_bh_locked']],on=['species','metabolite'])
checks.update({'validation_max_abs_r_error':float((vcomp.r-vcomp.partial_spearman_validation).abs().max()),'validation_max_abs_p_error':float((vcomp.p_legacy_n_minus_2-vcomp.p_validation).abs().max()),'validation_max_abs_q_global_error':float((vcomp.q_global_legacy-vcomp.q_bh_locked).abs().max()),'validation_max_abs_q_per_taxon_error':float((vcomp.q_per_taxon_legacy-vcomp.q_bh_locked).abs().max())})
disc.to_csv(O/'original_discovery_reproduced.csv',index=False);vv.to_csv(O/'original_validation_reproduced.csv',index=False)
(O/'original_reproduction_checks.json').write_text(json.dumps(checks,indent=2),encoding='utf-8');print('BASELINE',json.dumps(checks),flush=True)

# Revision-stage single partition, without changing any outcome-dependent assignment.
unified=oldman.partition.copy();unified.loc[disease.index]=disease['split'];pd.DataFrame({'subject_id':ids,'original_paired_partition':oldman.partition,'unified_partition':unified,'original_disease_partition':disease['split'].reindex(ids)}).to_csv(O/'unified_participant_manifest.csv',index=False)
di=unified.index[unified.eq('discovery')];vi=unified.index[unified.eq('validation')]
assert (unified.loc[disease.index]==disease['split']).all();assert (len(di),len(vi))==(207,140)
did=disease.index[disease['split'].eq('discovery')];case=clinical.loc[did,'Group'].isin(CRC)
eligible=S.columns[S.loc[did].gt(0).mean()>=.1];dr=[]
for sp in eligible:
 a=S.loc[did,sp][case].to_numpy();b=S.loc[did,sp][~case].to_numpy();u,p=mannwhitneyu(a,b,alternative='two-sided');dr.append({'species':sp,'prevalence_discovery':S.loc[did,sp].gt(0).mean(),'n_crc':len(a),'n_healthy':len(b),'p':p,'rank_biserial':2*u/(len(a)*len(b))-1})
dr=pd.DataFrame(dr);dr['q']=bh(dr.p);dr['discovery_selected']=dr.q<.05;dr.to_csv(O/'disease_discovery_all_species.csv',index=False)
selected=dr.loc[dr.discovery_selected,'species'].tolist();print('DISCOVERY-ONLY TAXA',selected,flush=True)
rawsp=pd.read_csv(I/'ST14b_CRCSpecies.csv');locked_old=set(rawsp.loc[rawsp.discovery_candidate.astype(str).str.lower().eq('true'),'feature']);assert set(selected)==locked_old,'Discovery species differ from submitted disease discovery'
pc=float(S.loc[di].to_numpy()[S.loc[di].to_numpy()>0].min()/2);log=np.log(S+pc);clr=log.sub(log.mean(axis=1),axis=0)
metfilter=(M.loc[di].fillna(0).ne(0).mean()>=.2)&(M.loc[di].nunique()>2);mets=M.columns[metfilter].tolist()
newparts={}
for part,ix in [('discovery',di),('validation',vi)]:
 rr,aa=associate(clinical.loc[ix],clr.loc[ix,selected],M.loc[ix,mets],'numeric_explicit');newparts[part]=rr;audits.append(dict(analysis='unified_revision',partition=part,**aa))
nd=newparts['discovery'];nd['q_discovery_per_taxon']=nd.groupby('species').p.transform(lambda v:bh(v));cand=nd.loc[nd.q_discovery_per_taxon<.10,['species','metabolite']]
newparts['validation'].to_csv(O/'unified_validation_all_eligible.csv',index=False)
nv=newparts['validation'].merge(cand,on=['species','metabolite']);nv['q_validation_locked_per_taxon']=nv.groupby('species').p.transform(lambda v:bh(v))
combined=nd.merge(nv,on=['species','metabolite'],suffixes=('_discovery','_validation'),how='left');combined['discovery_candidate']=combined.q_discovery_per_taxon<.1;combined['direction_concordant']=np.sign(combined.r_discovery)==np.sign(combined.r_validation);combined['heldout_supported']=combined.discovery_candidate & combined.direction_concordant & combined.q_validation_locked_per_taxon.lt(.1)
nd.to_csv(O/'unified_discovery_all_tests.csv',index=False);nv.to_csv(O/'unified_locked_validation_all.csv',index=False);combined.to_csv(O/'unified_results_complete.csv',index=False)
comparison=[]
for tag,d,v in [('original_reproduced',disc,vv),('unified_revision',nd,nv)]:
 for part,rr in [('discovery',d),('validation',v)]:
  rec=rr.loc[rr.species.eq(TARGET)&rr.metabolite.eq(MET)].iloc[0].to_dict();rec['analysis']=tag;rec['partition']=part;comparison.append(rec)
pd.DataFrame(comparison).to_csv(O/'principal_association_comparison.csv',index=False)

# Joint coefficients are descriptive post-selection adjustment, not another replication gate.
joints=[]
for label,ix in [('discovery',di),('validation',vi),('all',clinical.index),('CRC',clinical.index[clinical.Group.isin(CRC)]),('Healthy',clinical.index[clinical.Group.eq('Healthy')])]:
 c=clinical.loc[ix];x,valid,D,names=design(c,'numeric_explicit');tx=rint_frame(clr.loc[ix,selected]);y=invnorm(M.loc[ix,MET]);D=np.column_stack([D,tx.loc[valid].to_numpy()]);yy=y[valid];rank=np.linalg.matrix_rank(D);df=len(yy)-rank;b=np.linalg.lstsq(D,yy,rcond=None)[0];e=yy-D@b;V=np.linalg.pinv(D.T@D)*(e@e/df);j=len(names)+selected.index(TARGET);se=np.sqrt(V[j,j]);tt=t.ppf(.975,df)
 joints.append({'analysis':label,'species':TARGET,'metabolite':MET,'n':len(yy),'beta_joint':b[j],'se':se,'df':df,'ci_low':b[j]-tt*se,'ci_high':b[j]+tt*se,'p_unadjusted_descriptive':2*t.sf(abs(b[j]/se),df),'joint_taxa_count':len(selected),'role':'post_selection_descriptive_not_independent_validation'})
pd.DataFrame(joints).to_csv(O/'principal_joint_model_descriptive.csv',index=False)

# Fixed-seed participant bootstrap, refitting RINT and covariate adjustment for the primary pair.
rng=np.random.default_rng(SEED);boot=[]
for part,ix in [('discovery',di),('validation',vi)]:
 c=clinical.loc[ix].copy();sx=clr.loc[ix,TARGET].to_numpy();my=M.loc[ix,MET].to_numpy();vals=[]
 for rep in range(2000):
  z=rng.integers(0,len(ix),len(ix));cc=c.iloc[z].copy();cc.index=range(len(z));_,ok,D,_=design(cc,'numeric_explicit');a=invnorm(sx[z])[ok];b=invnorm(my[z])[ok];a-=D@np.linalg.lstsq(D,a,rcond=None)[0];b-=D@np.linalg.lstsq(D,b,rcond=None)[0];vals.append(float(pearsonr(a,b).statistic))
 lo,hi=np.quantile(vals,[.025,.975]);boot.append({'partition':part,'replicates':2000,'seed':SEED,'ci_low_percentile':lo,'ci_high_percentile':hi});pd.DataFrame({'r':vals}).to_csv(O/f'principal_bootstrap_{part}.csv',index=False)
pd.DataFrame(boot).to_csv(O/'principal_bootstrap_intervals.csv',index=False)
(O/'design_matrices_audit.json').write_text(json.dumps(audits,indent=2,ensure_ascii=False),encoding='utf-8')
main=combined.loc[combined.species.eq(TARGET)&combined.metabolite.eq(MET)].iloc[0].to_dict()
summary={'revision_plan':'2026-10-18 revision-stage frozen sensitivity; not external independent confirmation','n_discovery':len(di),'n_validation':len(vi),'discovery_only_taxa':selected,'n_filtered_metabolites':len(mets),'n_discovery_tests':len(nd),'n_locked_validation_tests':len(nv),'n_supported':int(combined.heldout_supported.sum()),'principal':main,'pseudocount_original':fullpc,'pseudocount_unified_discovery_only':pc,'original_reproduction':checks,'bootstrap':boot,'versions':{'numpy':np.__version__,'pandas':pd.__version__,'scipy':__import__('scipy').__version__}}
(O/'analysis_summary.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False,default=lambda x:x.item() if hasattr(x,'item') else str(x)),encoding='utf-8')
print(json.dumps(summary,ensure_ascii=False,default=str),flush=True)
