# Layout-only revision. Existing analysis outputs are read without re-estimation.
Sys.setlocale('LC_CTYPE','Chinese (Simplified)_China.utf8')
options(stringsAsFactors=FALSE)
library(ggplot2);library(grid);library(scales);library(jsonlite)
root<-normalizePath('..',winslash='/')
version<-file.path(root,'02_\u4e3b\u56fe','\u56fe7\u56fe8_\u5206\u56fe\u91cd\u6392_20261019')
panels<-file.path(version,'01_Panels');old<-file.path(version,'00_Previous');out<-file.path(version,'02_Combined')
for(p in c(version,panels,old,out))dir.create(p,recursive=TRUE,showWarnings=FALSE)
for(i in c(7,8))for(ext in c('pdf','svg','png','tif')){
 f<-file.path(root,'02_\u4e3b\u56fe',paste0('Figure_',i,'.',ext))
 if(file.exists(f)&&!file.exists(file.path(old,basename(f))))file.copy(f,old)
}
# Reuse the existing data mapping and object creation, but suppress ALL old exports.
prior<-parse('draw_revised_figures.R',encoding='UTF-8')
for(expr in prior){
 name<-if(is.call(expr))as.character(expr[[1]])[1] else ''
 if(!name%in%c('savefig','capture.output'))eval(expr,envir=.GlobalEnv)
}
font<-'Arial';body_size<-8.5;tick_size<-8
base<-theme_classic(base_size=body_size,base_family=font)+theme(
 axis.text=element_text(size=tick_size,colour='#20242A'),axis.title=element_text(size=body_size),
 axis.line=element_line(linewidth=.35),axis.ticks=element_line(linewidth=.3),
 plot.title=element_blank(),plot.tag=element_blank(),plot.margin=margin(1,1,1,1,'mm'),
 legend.title=element_text(size=8),legend.text=element_text(size=8),
 legend.key.height=unit(3,'mm'),legend.key.width=unit(3.5,'mm'),
 legend.margin=margin(0,0,0,0),legend.box.margin=margin(0,0,0,0),
 strip.background=element_blank(),strip.text=element_text(size=8.5,face='bold'),panel.spacing=unit(5,'mm'))
theme_set(base)
pad_plot<-function(p){p$theme<-base;p+labs(title=NULL,tag=NULL)}
bp<-ggplot()+geom_hline(yintercept=0,colour='#D8DDE3',linewidth=.3)+geom_vline(xintercept=0,colour='#D8DDE3',linewidth=.3)+
 geom_abline(slope=1,intercept=0,linetype=2,colour=grey,linewidth=.4)+
 geom_point(data=rp[rp$focal=='Other supported pairs',],aes(r_discovery,r_validation),colour=grey,size=1.9)+
 geom_point(data=rp[rp$focal=='Glycocholate candidate',],aes(r_discovery,r_validation),shape=23,fill=coral,colour=ink,size=2.8,stroke=.45)+
 scale_x_continuous(breaks=c(-.2,0,.2))+scale_y_continuous(breaks=c(-.2,0,.2))+
 labs(x='Discovery residual r',y='Held-out residual r')+
 annotate('point',x=-.31,y=.31,shape=23,fill=coral,colour=ink,size=2.2)+
 annotate('text',x=-.28,y=.31,label='Glycocholate',hjust=0,size=8/ggplot2::.pt,family=font)+
 coord_cartesian(xlim=c(-.35,.34),ylim=c(-.37,.37))
cp<-pad_plot(pC)+labs(x='Joint coefficient (95% CI)')+theme(axis.text.y=element_text(size=8))+
 scale_x_continuous(breaks=c(-.2,0,.2,.4))
dp<-pad_plot(pD)+labs(x='Joint coefficient (95% CI)')+scale_x_continuous(breaks=c(0,.25,.5))+
 scale_y_discrete(labels=c('Healthy (127)','CRC (147)','All paired (344)'))+theme(axis.text.y=element_text(size=8))
ep<-pad_plot(pE)+theme(legend.position='bottom',legend.direction='horizontal')
ee$offset<-rep(c(-.14,0,.14),length.out=nrow(ee));ee$x<-as.numeric(ee$condition)+ee$offset
fp<-ggplot(ee,aes(x,value,colour=condition,shape=condition))+geom_point(size=2.1,stroke=.45)+
 facet_wrap(~gene,nrow=1,scales='free_y')+scale_colour_manual(values=c(Control=grey,GCA=coral))+
 scale_shape_manual(values=c(Control=16,GCA=17))+
 scale_x_continuous(breaks=c(1,2),labels=c('Control','GCA'),limits=c(.65,2.35))+
 labs(x=NULL,y='Voom log2 expression')+theme(legend.position='none',strip.text=element_text(face='bold.italic'))
# Figure 8: retain all values and rules; only layout, labels and typography change.
ap8<-pad_plot(qA)+scale_x_discrete(labels=c('Microbial\nreplication','Human\nmetabolite','Taxon–\nmetabolite','Metabolite–\nhost','Host\nreplication','Cell-type\nlocalization','Contradiction\nresolved','Analytical\nrobustness'))+
 scale_y_discrete(labels=c('Source component comparator'='Source comparator','CRC focal candidate'='CRC focal candidate'))+
 theme(axis.line=element_blank(),axis.ticks=element_blank(),axis.text.x=element_text(size=8,hjust=.5,angle=0),
       legend.position='bottom')+guides(fill=guide_colourbar(barwidth=unit(26,'mm'),barheight=unit(2.5,'mm'),title.position='left'))
bp8<-pad_plot(qB)+scale_x_continuous(breaks=c(0,.5,1),labels=percent_format(accuracy=1))+
 labs(x='Promotion frequency')+theme(axis.text.y=element_text(size=8))
cp8<-pad_plot(qC)+labs(x='Decision-change rate',colour=NULL,shape=NULL)+
 theme(legend.position='bottom',legend.direction='horizontal')
dp8<-pad_plot(qD)+facet_wrap(~outcome,nrow=1,labeller=as_labeller(c(
 'Promotion of single-missing states'='Promotion of single-missing states',
 'Stopping of complete states'='Stopping of complete states')))+
 scale_x_continuous(breaks=c(.05,.10,.20),labels=percent_format(accuracy=1))+
 labs(x='Per-dimension coding error',y='Constructed-state error rate')+
 theme(legend.position='bottom',legend.direction='horizontal',legend.text=element_text(size=8),panel.spacing=unit(8,'mm'))

u<-function(x)unit(x,'mm')
gp<-function(size=8.5,face='plain',col=ink)gpar(fontfamily=font,fontsize=size,fontface=face,col=col)
labelbox<-function(x,y,w,h,text,fill,size=8.5){grobTree(
 roundrectGrob(x=u(x),y=u(y),width=u(w),height=u(h),r=u(1),gp=gpar(fill=fill,col='#83909C',lwd=.55)),
 textGrob(text,x=u(x),y=u(y),gp=gp(size))) }
arrowline<-function(x1,x2,y)segmentsGrob(x0=u(x1),x1=u(x2),y0=u(y),y1=u(y),arrow=arrow(type='closed',length=u(1.4)),gp=gpar(col=grey,lwd=.75))
schematic7A<-function(w,h){
 grobTree(labelbox(42,h-6,76,11,'347 paired participants\n207 discovery / 140 held-out','#E7EDF4'),
 labelbox(w-42,h-6,76,11,'Complete adjusted samples\n205 discovery / 139 held-out','#E0EEEB'),
 arrowline(81,w-81,h-6),
 textGrob('Four source-selected taxa · 252 metabolites · 1,008 tests',x=u(w/2),y=u(6.8),gp=gp(8)),
 textGrob('112 held-out participants contributed to upstream taxon selection',x=u(w/2),y=u(2.5),gp=gp(8)))
}
schematic7G<-function(w,h){grobTree(
 labelbox(42,h-5.2,78,10.3,'Human cohort: P. stomatis + glycocholate\nWithin-cohort covariation','#E7EDF4',8),
 labelbox(w-42,h-5.2,78,10.3,'Separate GCA expression dataset\nSOX14 / ZDHHC9 / CD274 response','#F2E3DF',8),
 textGrob('TRIANGULATED CANDIDATE FOR BIOLOGICAL FOLLOW-UP',x=u(w/2),y=u(2.4),gp=gp(8,'bold')))}
schematic8E<-function(w,h){ww<-(w-8)/3;grobTree(
 labelbox(ww/2,h/2,ww,h-1,'HCC\nLayer-level findings\nIncomplete connections','#E9D7D5',8),
 labelbox(w/2,h/2,ww,h-1,'CRC\nTriangulated candidate\nTargeted follow-up','#D0E6DF',8),
 labelbox(w-ww/2,h/2,ww,h-1,'Rule analysis\nExecutable specification\nBoundary sensitivity','#DCE7F2',8))}

# All coordinates are physical millimetres. Headers are separate from plotting areas.
makepanel<-function(id,title,w,h,plot=NULL,draw=NULL){
 header<-grobTree(textGrob(sub('.*_','',id),x=u(0),y=u(h-.3),just=c('left','top'),gp=gp(11,'bold')),
 textGrob(title,x=u(6),y=u(h-.8),just=c('left','top'),gp=gp(9,'bold')))
 body_h<-h-7
 body<-if(!is.null(plot))ggplotGrob(plot) else draw(w-2,body_h-1)
 if(!is.null(plot)){
  # Resolve label/axis extents on the native device before serializing the panel.
  # Only plotting columns/rows retain null units; no parent-dependent label widths.
  for(k in seq_along(body$widths))if(unitType(body$widths[k])!='null')body$widths[k]<-unit(convertWidth(body$widths[k],'mm',valueOnly=TRUE),'mm')
  for(k in seq_along(body$heights))if(unitType(body$heights[k])!='null')body$heights[k]<-unit(convertHeight(body$heights[k],'mm',valueOnly=TRUE),'mm')
 }
 body<-grobTree(body,vp=viewport(x=u(1),y=u(.5),width=u(w-2),height=u(body_h-1),just=c('left','bottom'),clip='off'))
 list(id=id,title=title,width_mm=w,height_mm=h,grob=grobTree(header,body))
}
invisible(ragg::agg_capture(width=180,height=270,units='mm',res=300))
specs<-list(
 makepanel('Figure_7_A','Paired analysis and selection dependency',172,32,draw=schematic7A),
 makepanel('Figure_7_B','18 held-out associations',68,74,plot=bp),
 makepanel('Figure_7_C','Eight post-selection associations',100,74,plot=cp),
 makepanel('Figure_7_D','Glycocholate attribution',68,62,plot=dp),
 makepanel('Figure_7_E','GCA expression PCA',100,62,plot=ep),
 makepanel('Figure_7_F','Source-derived gene responses',172,51,plot=fp),
 makepanel('Figure_7_G','Complementary evidence defines a candidate',172,27,draw=schematic7G),
 makepanel('Figure_8_A','Evidence profiles and bounded interpretation',172,64,plot=ap8),
 makepanel('Figure_8_B','256 constructed states',84,60,plot=bp8),
 makepanel('Figure_8_C','2,048 directed transitions',84,60,plot=cp8),
 makepanel('Figure_8_D','Coding-error trade-offs',172,64,plot=dp8),
 makepanel('Figure_8_E','Practical interpretation levels',172,27,draw=schematic8E))
dev.off()
alignrow<-function(indices){
 tables<-lapply(indices,function(i)specs[[i]]$grob$children[[2]]$children[[1]])
 stopifnot(length(unique(vapply(tables,function(g)length(g$heights),integer(1))))==1)
 heights<-do.call(unit.pmax,lapply(tables,function(g)g$heights))
 for(i in indices)specs[[i]]$grob$children[[2]]$children[[1]]$heights<<-heights
}
alignrow(c(2,3));alignrow(c(4,5));alignrow(c(9,10))
savepanel<-function(p){
 path<-file.path(panels,p$id);saveRDS(p,paste0(path,'.rds'))
 svglite::svglite(paste0(path,'.svg'),width=p$width_mm/25.4,height=p$height_mm/25.4);grid.newpage();grid.draw(p$grob);dev.off()
 cairo_pdf(paste0(path,'.pdf'),width=p$width_mm/25.4,height=p$height_mm/25.4,family=font);grid.newpage();grid.draw(p$grob);dev.off()
 ragg::agg_png(paste0(path,'.png'),width=p$width_mm,height=p$height_mm,units='mm',res=300);grid.newpage();grid.draw(p$grob);dev.off()
 ragg::agg_tiff(paste0(path,'.tif'),width=p$width_mm,height=p$height_mm,units='mm',res=600,compression='lzw');grid.newpage();grid.draw(p$grob);dev.off()
 cat('SAVED',p$id,'\n')
}
for(p in specs)savepanel(p)
layout7<-data.frame(panel=paste0('Figure_7_',LETTERS[1:7]),x=c(4,4,76,4,76,4,4),y=c(4,40,40,118,118,184,239),w=c(172,68,100,68,100,172,172),h=c(32,74,74,62,62,51,27))
layout8<-data.frame(panel=paste0('Figure_8_',LETTERS[1:5]),x=c(4,4,92,4,4),y=c(4,72,72,136,204),w=c(172,84,84,172,172),h=c(64,60,60,64,27))
write.csv(layout7,file.path(version,'Figure_7_layout_mm.csv'),row.names=FALSE)
write.csv(layout8,file.path(version,'Figure_8_layout_mm.csv'),row.names=FALSE)
write_json(list(backend='R',layout_only=TRUE,statistics_reestimated=FALSE,panels=12,
 figure7=list(width_mm=180,height_mm=270),figure8=list(width_mm=180,height_mm=235),
 observations=list(held_out_pairs=nrow(rp),postselection_pairs=nrow(ss),PCA_samples=nrow(pca),gene_observations=nrow(ee),evidence_cells=nrow(gm),constructed_states=nrow(st),transitions=2048)),
 file.path(version,'layout_contract.json'),pretty=TRUE,auto_unbox=TRUE)
capture.output(sessionInfo(),file=file.path(version,'R_sessionInfo.txt'))
