"""Portable verification of independent ratings and unified-partition BH.
Run from any extracted Supplementary Data 2 folder with standard Python only.
"""
from pathlib import Path
import csv,json
ROOT=Path(__file__).resolve().parents[1]
def read(p):
    with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def bh(p):
    ix=sorted(range(len(p)),key=lambda i:p[i]);q=[0.]*len(p);last=1.
    for rank in range(len(p),0,-1):
        i=ix[rank-1];last=min(last,p[i]*len(p)/rank);q[i]=last
    return q
a={r['item_id']:r for r in read(ROOT/'06_输入与依据/original_ratings_Wang_Yifei.csv')}
b={r['item_id']:r for r in read(ROOT/'06_输入与依据/independent_rater_Hu_Jiangshan.csv')}
assert len(a)==len(b)==48 and set(a)==set(b)
agreement=[]
for block,levels in [('HCC',[0,.25,.5,.75,1]),('CRC',[0,.5,1])]:
    ids=[i for i in a if a[i]['block']==block]
    x=[float(a[i]['score']) for i in ids];y=[float(b[i]['score']) for i in ids]
    n=len(ids);k=len(levels)
    obs=sum((levels.index(u)-levels.index(v))**2/(k-1)**2 for u,v in zip(x,y))/n
    exp=sum((i-j)**2/(k-1)**2*x.count(u)*y.count(v)/n**2 for i,u in enumerate(levels) for j,v in enumerate(levels))
    agreement.append(dict(assessment=block,items=n,agree=sum(u==v for u,v in zip(x,y)),exact_agreement=sum(u==v for u,v in zip(x,y))/n,quadratic_weighted_kappa=1-obs/exp if exp else None))
s=ROOT/'05_分析结果/02_CRC统一分区分析'
d=read(s/'unified_discovery_all_tests.csv');v={(r['species'],r['metabolite']):r for r in read(s/'unified_validation_all_eligible.csv')}
qd=bh([float(r['p']) for r in d]);chosen=[(r,q) for r,q in zip(d,qd) if q<.1]
qv=bh([float(v[(r['species'],r['metabolite'])]['p']) for r,q in chosen])
focal=None
for (r,q),q2 in zip(chosen,qv):
    if r['species']=='Peptostreptococcus stomatis' and r['metabolite']=='C01921_Glycocholate':
        vr=v[(r['species'],r['metabolite'])];focal=dict(discovery_r=float(r['r']),discovery_q=q,heldout_r=float(vr['r']),heldout_q=q2)
result=dict(ratings=agreement,global_BH_discovery_tests=len(d),global_BH_selected_tests=len(chosen),focal=focal)
target=ROOT/'05_分析结果/independent_ratings/verification.json';target.parent.mkdir(exist_ok=True,parents=True)
target.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False,indent=2))
