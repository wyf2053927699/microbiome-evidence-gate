"""Extract the unchanged alternative-profiler input from public Yachida Table_S8-1.
Usage: python extract_motu_from_source.py /path/to/Yachida_Supplementary_Tables_1-15.xlsx
"""
from pathlib import Path
import sys
import pandas as pd
from openpyxl import load_workbook
root=Path(__file__).resolve().parents[1]
wb=load_workbook(Path(sys.argv[1]),read_only=True,data_only=True)
rows=list(wb['Table_S8-1'].iter_rows(values_only=True));head=rows[3]
cols=[0]+[i for i,x in enumerate(head) if i>0 and x is not None]
z=pd.DataFrame([[r[i] if i<len(r) else None for i in cols] for r in rows[4:] if r[0] is not None],columns=[str(head[i]) for i in cols]);wb.close()
matrix=z.set_index(z.columns[0]).T.apply(pd.to_numeric,errors='coerce');matrix.index=matrix.index.astype(str)
ids=pd.read_csv(root/'06_输入与依据/ST16a_CRCManifest.csv',dtype={'subject_id':str}).subject_id
matrix.loc[ids].to_csv(root/'06_输入与依据/input_motu.csv',index_label='subject_id')
print('Extracted all alternative-profiler taxa for',len(ids),'paired participants.')
