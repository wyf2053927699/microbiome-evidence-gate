from pathlib import Path
import sys,json
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[1];WORK=ROOT.parent
import numpy as np,pandas as pd
from scipy.stats import norm,rankdata,t
from scipy.linalg import qr
from openpyxl import load_workbook
I=ROOT/'06_输入与依据';O=ROOT/'05_分析结果/CRC_calibrated';O.mkdir(exist_ok=True)
taxa=['Peptostreptococcus stomatis','Gemella morbillorum','Fusobacterium nucleatum','Parvimonas unclassified']
cv=['Group','Age','Gender','BMI','Brinkman Index','Alcohol','Tumor location'];num=['Age','BMI','Brinkman Index','Alcohol']
C=pd.read_pickle(I/'input_clinical_original_dtypes.pkl');C.index=C.index.astype(str)
S=pd.read_csv(I/'input_species.csv',dtype={'subject_id':str}).set_index('subject_id')
M=pd.read_csv(I/'input_metabolites.csv',dtype={'subject_id':str}).set_index('subject_id')
man=pd.read_csv(I/'ST16a_CRCManifest.csv',dtype={'subject_id':str}).set_index('subject_id');ids=man.index
C=C.loc[ids];S=S.loc[ids];M=M.loc[ids]
def bh(p):
 v=np.asarray(p,float);v=np.where(np.isfinite(v),v,1);ix=np.argsort(v);z=np.minimum.accumulate((v[ix]*len(v)/np.arange(1,len(v)+1))[::-1])[::-1];r=np.empty(len(v));r[ix]=np.minimum(z,1);return r
def rint(a):
 a=np.asarray(a,float);ok=np.isfinite(a);v=np.full(len(a),np.nan);v[ok]=norm.ppf((rankdata(a[ok],method='average')-.5)/ok.sum());return v
def clr(s):
 a=s.to_numpy();pc=a[a>0].min()/2;z=np.log(s+pc);return z.sub(z.mean(axis=1),axis=0),pc
SC,pc=clr(S)
audits=[]
def design(idx,covs,mode):
 c=C.loc[idx,covs].copy()
 if mode=='numeric':
  for k in num:
   if k in c:c[k]=pd.to_numeric(c[k],errors='coerce')
  c=pd.get_dummies(c,columns=[k for k in covs if k not in num],drop_first=True,dtype=float)
 else:c=pd.get_dummies(c,drop_first=True,dtype=float).apply(pd.to_numeric,errors='coerce')
 c=c[[k for k in c if c[k].nunique(dropna=True)>1]];ok=c.notna().all(axis=1).to_numpy()
 d=np.column_stack([np.ones(ok.sum()),c.loc[ok].to_numpy(float)]);rk=int(np.linalg.matrix_rank(d));_,_,piv=qr(d,mode='economic',pivoting=True);names=['Intercept']+list(c);sel=sorted(piv[:rk]);d=d[:,sel]
 audits.append(dict(mode=mode,n_subset=len(idx),n_complete=len(d),rank=rk,columns=[names[x] for x in sel],excluded=list(np.asarray(idx)[~ok])))
 return ok,d
def association(idx,exposure,metabolites,covs,mode,pairs=None,label=''):
 ok,d=design(idx,covs,mode);n=len(d);df=n-d.shape[1]-1
 xp=pd.DataFrame({k:rint(exposure.loc[idx,k]) for k in exposure},index=idx).to_numpy()[ok]
 yp=pd.DataFrame({k:rint(M.loc[idx,k]) for k in metabolites},index=idx).to_numpy()[ok]
 xp=xp-d@np.linalg.lstsq(d,xp,rcond=None)[0];yp=yp-d@np.linalg.lstsq(d,yp,rcond=None)[0]
 xp=xp/np.sqrt((xp*xp).sum(axis=0));yp=yp/np.sqrt((yp*yp).sum(axis=0));rr=xp.T@yp
 rows=[];keys=pairs if pairs is not None else [(s,m) for s in exposure for m in metabolites]
 sm={s:i for i,s in enumerate(exposure)};mm={m:i for i,m in enumerate(metabolites)}
 for s,m in keys:
  r=float(np.clip(rr[sm[s],mm[m]],-.999999999,.999999999));p=float(2*t.sf(abs(r)*np.sqrt(df/(1-r*r)),df));z=np.arctanh(r);se=1/np.sqrt(n-d.shape[1]-2);lo,hi=np.tanh([z-1.95996398454*se,z+1.95996398454*se])
  rows.append(dict(analysis=label,species=s,metabolite=m,n=n,df=df,r=r,p=p,ci_low=lo,ci_high=hi))
 z=pd.DataFrame(rows);z['q']=bh(z.p);return z
di=ids[man.partition.eq('discovery')];vi=ids[man.partition.eq('validation')]
mets=M.columns[(M.loc[di].fillna(0).ne(0).mean()>=.2)&(M.loc[di].nunique()>2)].tolist()
assert len(mets)==252
summ={}
for mode in ['numeric','categorical']:
 disc=association(di,SC[taxa],mets,cv,mode,label='discovery');c=disc.loc[disc.q<.1,['species','metabolite']]
 val=association(vi,SC[taxa],mets,cv,mode,list(c.itertuples(index=False,name=None)),label='validation')
 a=disc.merge(val,on=['species','metabolite'],how='left',suffixes=('_discovery','_validation'))
 a['discovery_selected']=a.q_discovery.lt(.1);a['replicated']=a.discovery_selected&a.q_validation.lt(.1)&(np.sign(a.r_discovery)==np.sign(a.r_validation))
 disc.to_csv(O/f'{mode}_discovery.csv',index=False);val.to_csv(O/f'{mode}_validation.csv',index=False);a.to_csv(O/f'{mode}_all_pairs.csv',index=False)
 principal=a.loc[a.species.eq(taxa[0])&a.metabolite.eq('C01921_Glycocholate')]
 summ[mode]={'tests':len(a),'discovery_candidates':len(c),'replicated':int(a.replicated.sum()),'principal':principal.to_dict('records')}
 print(mode,json.dumps(summ[mode]),flush=True)
 if mode=='numeric':validated=a[a.replicated].copy()
# Read only the alternative profiler from the source workbook.
motu=pd.read_csv(I/'input_motu.csv',dtype={'subject_id':str}).set_index('subject_id').loc[ids];mc,mpc=clr(motu)
mapping=dict(zip(taxa,[taxa[0],taxa[1],taxa[2],'Parvimonas micra']))
me=pd.DataFrame({s:mc[mapping[s]] for s in taxa},index=ids)
pairs=list(validated[['species','metabolite']].itertuples(index=False,name=None));vm=list(dict.fromkeys(validated.metabolite));ri=ids[C.Group.isin(['Stage_0','Stage_I_II','Stage_III_IV'])];hi=ids[C.Group.eq('Healthy')]
rob=[]
for label,ix,expo,covs in [('motu',ids,me,cv),('crc',ri,SC[taxa],[k for k in cv if k!='Group']+['Stage']),('healthy',hi,SC[taxa],[k for k in cv if k not in ['Group','Tumor location']]),('presence',ids,(S[taxa]>0).astype(float),cv)]:
 rr=association(ix,expo,vm,covs,'numeric',pairs,label);rr.to_csv(O/f'robustness_{label}.csv',index=False);rob.append(rr)
 rr=rr[['species','metabolite','r','p','q','n','ci_low','ci_high']].rename(columns={k:f'{label}_{k}' for k in ['r','p','q','n','ci_low','ci_high']});validated=validated.merge(rr,on=['species','metabolite'])
validated['motu_exact']=validated.species.ne('Parvimonas unclassified')
validated['strict_robust']=((~validated.motu_exact)|((np.sign(validated.r_discovery)==np.sign(validated.motu_r))&validated.motu_q.lt(.1)))&(np.sign(validated.r_discovery)==np.sign(validated.crc_r))&validated.crc_q.lt(.1)&(np.sign(validated.r_discovery)==np.sign(validated.presence_r))&validated.presence_q.lt(.1)
validated.to_csv(O/'numeric_robustness_consensus.csv',index=False)
def joint(pairs,family):
 out=[]
 for label,ix,covs in [('all',ids,cv),('crc',ri,[k for k in cv if k!='Group']+['Stage']),('healthy',hi,[k for k in cv if k not in ['Group','Tumor location']])]:
  ok,d=design(ix,covs,'numeric');s=np.column_stack([rint(SC.loc[ix,k]) for k in taxa])[ok];d=np.column_stack([d,s]);rk=np.linalg.matrix_rank(d);df=len(d)-rk
  for sp,mt in pairs:
   y=rint(M.loc[ix,mt])[ok];b=np.linalg.lstsq(d,y,rcond=None)[0];e=y-d@b;V=np.linalg.pinv(d.T@d)*(e@e/df);j=d.shape[1]-4+taxa.index(sp);se=np.sqrt(V[j,j]);dd=t.ppf(.975,df)*se
   out.append(dict(family=family,analysis=label,species=sp,metabolite=mt,n=len(y),df=int(df),beta=b[j],se=se,ci_low=b[j]-dd,ci_high=b[j]+dd,p=2*t.sf(abs(b[j]/se),df)))
 out=pd.DataFrame(out);out['q']=out.groupby('analysis').p.transform(bh);return out
strict=validated.loc[validated.strict_robust,['species','metabolite']]
j=joint(list(strict.itertuples(index=False,name=None)),'recalibrated_strict_robust');j.to_csv(O/'joint_recalibrated.csv',index=False)
old72=pd.read_csv(I/'ST16e_JointModels.csv');jj=joint(list(old72[['species','metabolite']].itertuples(index=False,name=None)),'source72_fixed_audit');jj.to_csv(O/'joint_source72_audit.csv',index=False)
old6=pd.read_csv(I/'ST16f_LockedSix.csv');table=old6[['species','metabolite']].merge(jj,on=['species','metabolite']);table=table.merge(validated[['species','metabolite','strict_robust']],on=['species','metabolite'],how='left');table.to_csv(O/'table2_source_six_reestimated.csv',index=False)
newall=j[j.analysis.eq('all')&j.q.lt(.1)].merge(validated[['species','metabolite','r_discovery']],on=['species','metabolite']);newall=newall[np.sign(newall.beta)==np.sign(newall.r_discovery)];newall.to_csv(O/'postselection_all_supported.csv',index=False)
summ.update(strict_robust=int(validated.strict_robust.sum()),postselection_all_supported=len(newall),pseudocount=pc,motu_pseudocount=mpc,principal_robustness=validated.loc[validated.species.eq(taxa[0])&validated.metabolite.eq('C01921_Glycocholate')].to_dict('records'),principal_joint=j.loc[j.species.eq(taxa[0])&j.metabolite.eq('C01921_Glycocholate')].to_dict('records'))
(O/'summary.json').write_text(json.dumps(summ,ensure_ascii=False,indent=2),encoding='utf-8');(O/'design_audits.json').write_text(json.dumps(audits,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(summ,ensure_ascii=False),flush=True)
