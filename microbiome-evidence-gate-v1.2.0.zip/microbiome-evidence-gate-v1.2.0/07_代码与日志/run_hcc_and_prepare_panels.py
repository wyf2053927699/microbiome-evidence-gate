from pathlib import Path
import sys,json,shutil
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(Path(__file__).resolve().parent/'python_deps'))
import numpy as np,pandas as pd
from scipy.stats import t,nct,norm
from scipy.optimize import brentq
from openpyxl import load_workbook
I=ROOT/'06_输入与依据';O=ROOT/'05_分析结果/04_HCC精度与代谢物匹配';F=ROOT/'05_分析结果/figure_source'
O.mkdir(parents=True,exist_ok=True);F.mkdir(parents=True,exist_ok=True)
meta=pd.read_csv(I/'ST2a_PrimaryManifest.csv');m=meta.loc[meta.underlying_condition.isin(['AFLD','NAFLD'])&meta.age_adjusted_complete_case].copy();dummy=pd.get_dummies(m[['Condition','sex','underlying_condition']],drop_first=True,dtype=float);D=np.column_stack([np.ones(len(m)),m.age,dummy]);rank=int(np.linalg.matrix_rank(D));df=len(m)-rank
ext=pd.read_csv(I/'ST4c_MicrobiomeExt.csv');assert (ext.adjusted_n==len(m)).all();ext['model_rank']=rank;ext['residual_df']=df;ext['ci_low_t']=ext.adjusted_beta_HCC-t.ppf(.975,df)*ext.adjusted_se;ext['ci_high_t']=ext.adjusted_beta_HCC+t.ppf(.975,df)*ext.adjusted_se;ext['p_recomputed_t']=2*t.sf(abs(ext.adjusted_beta_HCC/ext.adjusted_se),df);ext['interpretation']=np.where((ext.ci_low_t<=0)&(ext.ci_high_t>=0),'limited_precision_CI_includes_zero','estimated_direction_supported_before_multiplicity');ext.to_csv(O/'HCC_external_effects_with_95CI.csv',index=False)
power=[]
for label,n1,n0 in [('external_full_unadjusted_design',95,10),('external_common_support_design',int(m.Condition.eq('HCC').sum()),int(m.Condition.eq('Cirrhosis').sum()))]:
 for alpha in [.05,.01]:
  dd=n1+n0-2;cut=t.ppf(1-alpha/2,dd)
  def fn(effect):
   nc=effect/np.sqrt(1/n1+1/n0);return nct.sf(cut,dd,nc)+nct.cdf(-cut,dd,nc)
  d80=brentq(lambda v:fn(v)-.8,.001,2);power.append({'design':label,'n_HCC':n1,'n_cirrhosis':n0,'alpha_two_sided':alpha,'power':.8,'detectable_standardized_difference':d80,'assumptions':'two-sample t approximation; not actual adjusted-model or BH power'})
pd.DataFrame(power).to_csv(O/'HCC_design_detectable_effects.csv',index=False)
checks=[
 ('HCC external microbiome',f'{len(m)} common-support complete participants','t-based CI available for 87 genera','approximate detectable effects supplied; no observed-P post-hoc power'),
 ('HCC longitudinal plasma','203 participants; repeated samples','clustered longitudinal design','power cannot be reduced to sample count without covariance/effect specification'),
 ('HCC liver metabolomics','up to 40 paired participants','paired contrasts with multiple testing','n_pairs and effects retained per metabolite; compartment/time differ from plasma'),
 ('HCC bulk host','independent cohorts','programme-level effects remain existing results','no new power model; retain effect direction and correction'),
 ('HCC single-cell','6 or 8 paired donors depending on cell type','donor is independent unit; 22 tests','exact sign-flip minimum unadjusted two-sided P is 0.03125 (6) or 0.0078125 (8)'),
 ('CRC paired unified','205 discovery;139 validation complete cases','covariate adjusted residual correlation','Fisher and participant bootstrap intervals supplied'),
 ('GCA perturbation','3 samples per group; biological independence unresolved','20 exact allocations','minimum two-sided programme P=0.10; model-based gene P values use different assumptions')]
pd.DataFrame(checks,columns=['check','independent_n','precision_or_design','power_or_resolution_note']).to_csv(O/'checks_precision_and_testability.csv',index=False)

pl=pd.read_csv(I/'ST6a_PlasmaIDs.csv');rob=pd.read_csv(I/'ST6b_PlasmaRobust.csv');tissue=pd.read_csv(I/'ST6d_TissueIdent.csv')
aliases={'lactic acid':'lactate','adenosine monophosphate':"adenosine 5'-monophosphate (AMP)",'malic acid':'malate','fumaric acid':'fumarate','succinic acid':'succinate','propionylcarnitine':'propionylcarnitine (C3)','glycerophosphocholine':'glycerophosphorylcholine (GPC)','glycerylphosphorylethanolamine':'glycerophosphoethanolamine','linoleic acid':'linoleate (18:2n6)'}
cross=[]
for name in tissue.metabolite.unique():
 match=pl.loc[pl.metabolite.str.casefold().eq(name.casefold())];kind='exact_annotation_name'
 if match.empty and name in aliases:match=pl.loc[pl.metabolite.eq(aliases[name])];kind='candidate_parent_or_synonym_not_structural_confirmation'
 if match.empty:
  cross.append({'tissue_name':name,'plasma_name':None,'match_class':'unresolved_or_sum_composition_lipid','structural_identity_confirmed':False});continue
 for a in match.itertuples():
  pp=rob.loc[rob.metabolite.eq(a.metabolite)];tt=tissue.loc[tissue.metabolite.eq(name)&tissue.contrast.eq('paired_HCC_vs_all_adjacent')]
  pq=float(pp.q_group_provided_area_gee.min());sq=float(pp.q_group_sample_median_scaled_gee.min());tq=float(tt.wilcoxon_q_eligible_family.min())
  cross.append({'tissue_name':name,'plasma_name':a.metabolite,'match_class':kind,'plasma_InChIKey':a.inchikey,'plasma_HMDB':a.hmdb,'plasma_KEGG':a.kegg,'tissue_structural_ID':None,'structural_identity_confirmed':False,'plasma_min_q_provided_GEE':pq,'plasma_min_q_scaled_GEE':sq,'plasma_any_longitudinal_promoted':bool(pp.longitudinal_promotion.fillna(False).any()),'tissue_min_q_eligible':tq,'annotation_level_both_FDR_screen':bool(pq<.1 and sq<.1 and tq<.05),'identity_boundary':'Tissue source lacks structural identifiers; no stereochemical identity inferred from names'})
cross=pd.DataFrame(cross);cross.to_csv(O/'metabolite_annotation_crosswalk_audit.csv',index=False)

print('HCC precision and chemical crosswalk complete')
