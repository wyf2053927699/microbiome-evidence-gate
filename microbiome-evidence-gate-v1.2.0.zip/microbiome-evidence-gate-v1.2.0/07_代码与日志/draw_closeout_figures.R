# Submission closeout: existing values only; no statistical re-estimation.
Sys.setlocale('LC_CTYPE','Chinese (Simplified)_China.utf8')
options(stringsAsFactors=FALSE)
library(ggplot2);library(patchwork);library(grid)
root<-normalizePath('..',winslash='/');src<-file.path(root,'05_分析结果','figure_source')
read<-function(x)read.csv(file.path(src,x),check.names=FALSE)
font<-'Arial';ink<-'#20242A';teal<-'#279C90';blue<-'#245B86';red<-'#C65A53';amber<-'#D89A27'
theme_set(theme_classic(base_size=8.5,base_family=font)+theme(axis.text=element_text(size=8,colour=ink),plot.margin=margin(4,5,4,5,'mm'),plot.tag=element_text(face='bold',size=11),legend.text=element_text(size=8),legend.title=element_text(size=8),legend.key.size=unit(3,'mm')))
export<-function(p,stem,w,h,folder){
 b<-file.path(root,folder,stem)
 svglite::svglite(paste0(b,'.svg'),width=w/25.4,height=h/25.4);print(p);dev.off()
 cairo_pdf(paste0(b,'.pdf'),width=w/25.4,height=h/25.4,family=font);print(p);dev.off()
 ragg::agg_png(paste0(b,'.png'),width=w,height=h,units='mm',res=300);print(p);dev.off()
 ragg::agg_tiff(paste0(b,'.tif'),width=w,height=h,units='mm',res=600,compression='lzw');print(p);dev.off()
}
shortp<-function(x){v<-c(cell_division='Cell division',respiratory_electron_transport_chain='Respiratory chain',ribosome_biogenesis='Ribosome biogenesis',type_I_interferon_response='Type I interferon');unname(v[x])}
# Figure 5: retain all effects and every matched-pair observation, move labels inside panel.
h<-read('host_cross_dataset.csv');h$label<-shortp(h$program)
a<-ggplot(h,aes(dataset,label,fill=effect))+geom_tile(colour='white',linewidth=.6)+geom_text(aes(label=sprintf('%.2f',effect)),size=2.6)+scale_fill_gradient2(low=blue,mid='white',high=red,midpoint=0,name='Effect')+labs(x=NULL,y=NULL,tag='A')+theme(axis.text.x=element_text(angle=35,hjust=1),axis.line=element_blank(),axis.ticks=element_blank(),legend.position='top')
t<-read('host_TCGA_pairs.csv');t$label<-shortp(t$program)
b<-ggplot(t,aes(label,paired_difference,colour=label))+geom_hline(yintercept=0,colour='#CBD2D9')+geom_point(position=position_jitter(width=.11,height=0,seed=20261019),size=1.2,alpha=.5)+stat_summary(fun=median,geom='point',shape=95,size=7)+labs(x=NULL,y='TCGA paired difference',tag='B')+theme(legend.position='none',axis.text.x=element_text(angle=40,hjust=1))
g<-read('host_GSE63898.csv');g<-g[g$family=='primary_PRJEB54571_GO_programs',];g$label<-shortp(g$program);g$replication<-ifelse(tolower(g$strict_three_dataset_replication)=='true','Replicated','Not replicated')
c<-ggplot(g,aes(plate_adjusted_beta,label,xmin=plate_adjusted_ci_low,xmax=plate_adjusted_ci_high,colour=replication))+geom_vline(xintercept=0,colour='#CBD2D9')+geom_errorbar(orientation='y',width=.15)+geom_point(size=2)+scale_colour_manual(values=c('Not replicated'=red,'Replicated'=teal))+labs(x='GSE63898 adjusted effect (95% CI)',y=NULL,tag='C',colour=NULL)+theme(legend.position='top')
g$display<-c(cell_division='Cell division',respiratory_electron_transport_chain='Respiratory\nchain',ribosome_biogenesis='Ribosome\nbiogenesis',type_I_interferon_response='Type I\ninterferon')[g$program]
g$labelx<-c(cell_division=.82,respiratory_electron_transport_chain=.43,ribosome_biogenesis=1.43,type_I_interferon_response=1.4)[g$program]
g$labely<-c(cell_division=.51,respiratory_electron_transport_chain=.1,ribosome_biogenesis=.29,type_I_interferon_response=.69)[g$program]
d<-ggplot(g,aes(tcga_median_paired_difference,plate_adjusted_beta,colour=replication))+geom_hline(yintercept=0,colour='#CBD2D9')+geom_vline(xintercept=0,colour='#CBD2D9')+geom_point(size=2.3)+geom_segment(aes(xend=labelx,yend=labely),linewidth=.25,alpha=.5,show.legend=FALSE)+geom_text(aes(x=labelx,y=labely,label=display),size=2.6,lineheight=.95,show.legend=FALSE)+scale_colour_manual(values=c('Not replicated'=red,'Replicated'=teal))+scale_x_continuous(limits=c(-.05,1.7))+scale_y_continuous(limits=c(-.03,.8))+labs(x='TCGA paired effect',y='GSE63898 adjusted effect',colour=NULL,tag='D')+theme(legend.position='top')
export((a+b)/(c+d),'Figure_5',183,175,'02_主图')
# Figure 4: preserve quarter-step values exactly and explicitly label priority scale.
x<-read('axis_dimension_scores.csv');dims<-names(x)[2:9]
family<-c('Bile acid / FXR','Aromatic metabolites / AHR','Tryptophan indoles / AHR','Choline / acyl-choline')
long<-do.call(rbind,lapply(seq_len(nrow(x)),function(i)data.frame(family=family[i],dimension=dims,value=as.numeric(x[i,dims]))))
long$family<-factor(long$family,levels=rev(family));long$dimension<-factor(long$dimension,levels=dims)
dl<-c('Microbial\nreplication','Human\nmetabolite','Taxon–\nmetabolite','Metabolite–\nhost','Bulk-host\nreplication','Single-cell\nlocalization','Contradiction\nresolution','Analytical\nrobustness')
a<-ggplot(long,aes(dimension,family,fill=value))+geom_tile(colour='white',linewidth=.7)+geom_text(aes(label=format(value,trim=TRUE,nsmall=2)),size=2.7)+scale_fill_gradientn(colours=c(red,'#F8ECD0',teal),limits=c(0,1),breaks=c(0,.25,.5,.75,1),name='Descriptive priority support',guide=guide_colourbar(barwidth=unit(50,'mm')))+scale_x_discrete(labels=dl)+labs(x=NULL,y=NULL,tag='A')+theme(axis.line=element_blank(),axis.ticks=element_blank(),legend.position='top',axis.text.x=element_text(angle=35,hjust=1))
e<-read('axis_edges_display.csv');w<-read('axis_weights_display.csv')
writeLines(paste('Edge columns:',paste(names(e),collapse=','),'Weight columns:',paste(names(w),collapse=',')))
e$label<-vapply(e$candidate_family,function(s)family[match(s,x$candidate_family)],character(1))
e$provenance<-ifelse(tolower(e$measured_in_project)=='yes','Measured in project','Curated prior only')
es<-aggregate(rep(1,nrow(e)),list(label=e$label,provenance=e$provenance),sum);names(es)[3]<-'n'
b<-ggplot(es,aes(x=n,y=label,fill=provenance))+geom_col(width=.65)+geom_text(aes(label=n),position=position_stack(vjust=.5),size=2.8)+labs(x='Traceable evidence links',y=NULL,fill=NULL,tag='B')+theme(legend.position='top')
w$label<-family[match(w$candidate_family,x$candidate_family)];w$weighting_scheme<-factor(w$weighting_scheme,levels=c('equal','measured_layer_emphasis','bridge_emphasis','validation_emphasis'),labels=c('Equal','Measured-layer\nemphasis','Bridge\nemphasis','Validation\nemphasis'))
c<-ggplot(w,aes(weighting_scheme,weighted_score,colour=label,group=label))+geom_line()+geom_point(size=2)+labs(x='Weighting scheme',y='Exploratory score',colour=NULL,tag='C')+theme(legend.position='bottom',legend.box='vertical',axis.text.x=element_text(angle=15,hjust=1))+guides(colour=guide_legend(nrow=2))
export(a/b/c+plot_layout(heights=c(1.35,.8,1)),'Figure_4',183,255,'02_主图')
# Supplementary Figure 1: complete legend rows and generous endpoint padding.
f<-read('s1_filters.csv');boot<-read('s1_bootstrap.csv');loo<-read('s1_leave_one_out.csv');ps<-read('s1_pseudocount.csv')
f$pos<-ave(seq_len(nrow(f)),f$layer,FUN=seq_along)
a<-ggplot(f,aes(pos,layer))+geom_line(aes(group=layer),colour='#8D99A6')+geom_point(aes(size=n),colour=blue)+geom_text(aes(label=n),vjust=-1,size=2.7)+geom_text(aes(label=stage),vjust=1.8,size=2.5)+scale_x_continuous(limits=c(.65,3.5),breaks=NULL)+scale_y_discrete(expand=expansion(add=.7))+labs(x=NULL,y=NULL,tag='A')+theme(legend.position='none')
b<-ggplot(boot,aes(median_difference_HCC_minus_Cirrhosis,metric,xmin=bootstrap_95_ci_low,xmax=bootstrap_95_ci_high))+geom_vline(xintercept=0,colour='#CBD2D9')+geom_errorbar(orientation='y',width=.1,colour=teal)+geom_point(colour=teal,size=2)+scale_y_discrete(labels=c(observed_asvs='Observed ASVs',shannon='Shannon',escherichia_shigella_clr='Escherichia–Shigella CLR'))+labs(x='HCC − cirrhosis median difference',y=NULL,tag='B')
loo$low<-loo$adjusted_beta_HCC-1.96*loo$adjusted_se;loo$high<-loo$adjusted_beta_HCC+1.96*loo$adjusted_se
c<-ggplot(loo,aes(adjusted_beta_HCC,reorder(omitted_cirrhosis_sample,adjusted_beta_HCC),xmin=low,xmax=high))+geom_vline(xintercept=0,colour='#CBD2D9')+geom_errorbar(orientation='y',width=.1,colour=blue)+geom_point(size=1.7,colour=blue)+labs(x='Adjusted HCC coefficient',y=NULL,tag='C')
dp<-rbind(data.frame(pseudo=ps$pseudocount_on_counts,n=ps$discovery_q_lt_0_10,stage='Discovery q < 0.10'),data.frame(pseudo=ps$pseudocount_on_counts,n=ps$locked_validation_pass,stage='Locked validation'),data.frame(pseudo=ps$pseudocount_on_counts,n=ps$external_age_adjusted_pass,stage='External adjusted'))
d<-ggplot(dp,aes(pseudo,n,colour=stage,shape=stage))+geom_line()+geom_point(size=2)+scale_colour_manual(values=c('Discovery q < 0.10'=blue,'External adjusted'=red,'Locked validation'=amber))+labs(x='Count pseudocount',y='Number of genera',colour=NULL,shape=NULL,tag='D')+theme(legend.position='top')+guides(colour=guide_legend(ncol=1),shape=guide_legend(ncol=1))
ep<-rbind(data.frame(pseudo=factor(ps$pseudocount_on_counts),n=ps$conventional_dl_all_omissions_p_lt_0_05,method='Conventional DL'),data.frame(pseudo=factor(ps$pseudocount_on_counts),n=ps$modified_hksj_all_omissions_p_lt_0_05,method='Modified Hartung–Knapp'))
e<-ggplot(ep,aes(pseudo,n,fill=method))+geom_col(position=position_dodge(.8),width=.7)+geom_text(aes(label=n),position=position_dodge(.8),vjust=-.4,size=2.7)+scale_fill_manual(values=c(teal,'#8995A2'))+scale_y_continuous(expand=expansion(mult=c(0,.15)))+labs(x='Count pseudocount',y='All-omission significant genera',fill=NULL,tag='E')+theme(legend.position='top')+guides(fill=guide_legend(ncol=1))
export(a/(b+c)/(d+e)+plot_layout(heights=c(.9,1.2,1.1)),'Supplementary_Figure_1',183,255,'03_补图与补充材料')
capture.output(sessionInfo(),file=file.path(src,'closeout_figure_sessionInfo.txt'))
