# Assemble the independently exported panel masters without raster scaling/cropping.
Sys.setlocale('LC_CTYPE','Chinese (Simplified)_China.utf8')
library(grid);library(gtable)
root<-normalizePath('..',winslash='/')
version<-file.path(root,'02_\u4e3b\u56fe','\u56fe7\u56fe8_\u5206\u56fe\u91cd\u6392_20261019')
panels<-file.path(version,'01_Panels');out<-file.path(version,'02_Combined')
drawfigure<-function(layout,height_mm){
 grid.newpage()
 for(i in seq_len(nrow(layout))){
  r<-layout[i,];p<-readRDS(file.path(panels,paste0(r$panel,'.rds')))
  stopifnot(p$width_mm==r$w,p$height_mm==r$h,r$x>=0,r$y>=0,r$x+r$w<=180,r$y+r$h<=height_mm)
  pushViewport(viewport(x=unit(r$x,'mm'),y=unit(height_mm-r$y-r$h,'mm'),width=unit(r$w,'mm'),height=unit(r$h,'mm'),just=c('left','bottom'),clip='off'))
  grid.draw(p$grob);popViewport()
 }
}
for(i in c(7,8)){
 layout<-read.csv(file.path(version,paste0('Figure_',i,'_layout_mm.csv')))
 for(a in seq_len(nrow(layout)))for(b in seq_len(nrow(layout)))if(a<b){
  A<-layout[a,];B<-layout[b,]
  stopifnot(A$x+A$w<=B$x||B$x+B$w<=A$x||A$y+A$h<=B$y||B$y+B$h<=A$y)
 }
 h<-if(i==7)270 else 235;b<-file.path(out,paste0('Figure_',i))
 svglite::svglite(paste0(b,'.svg'),width=180/25.4,height=h/25.4);drawfigure(layout,h);dev.off()
 cairo_pdf(paste0(b,'.pdf'),width=180/25.4,height=h/25.4,family='Arial');drawfigure(layout,h);dev.off()
 ragg::agg_png(paste0(b,'.png'),width=180,height=h,units='mm',res=300);drawfigure(layout,h);dev.off()
 ragg::agg_tiff(paste0(b,'.tif'),width=180,height=h,units='mm',res=600,compression='lzw');drawfigure(layout,h);dev.off()
 cat('ASSEMBLED Figure',i,'from',nrow(layout),'independent panel masters\n')
}
