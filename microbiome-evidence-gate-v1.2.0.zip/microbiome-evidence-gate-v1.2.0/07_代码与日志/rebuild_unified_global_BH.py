"""Rebuild the manuscript global-BH family from all recomputed eligible tests."""
from pathlib import Path
import csv,json
root=Path(__file__).resolve().parents[1]
out=root/'05_分析结果/02_CRC统一分区分析'
def read(name):
    with (out/name).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def bh(p):
    order=sorted(range(len(p)),key=p.__getitem__);q=[0.]*len(p);last=1.
    for rank in range(len(p),0,-1):
        i=order[rank-1];last=min(last,p[i]*len(p)/rank);q[i]=last
    return q
d=read('unified_discovery_all_tests.csv')
v={(r['species'],r['metabolite']):r for r in read('unified_validation_all_eligible.csv')}
selected=[(r,q) for r,q in zip(d,bh([float(r['p']) for r in d])) if q<.1]
qv=bh([float(v[(r['species'],r['metabolite'])]['p']) for r,q in selected])
rows=[]
for (r,q),q2 in zip(selected,qv):
    vr=v[(r['species'],r['metabolite'])];concordant=float(r['r'])*float(vr['r'])>0
    rows.append(dict(species=r['species'],metabolite=r['metabolite'],r_discovery=float(r['r']),p_discovery=float(r['p']),q_discovery=q,r_validation=float(vr['r']),p_validation=float(vr['p']),q_validation=q2,direction_concordant=concordant,supported=concordant and q2<.1))
with (out/'unified_global_BH_verified.csv').open('w',encoding='utf-8',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
summary=dict(discovery_tests=len(d),selected_heldout_tests=len(selected),supported=sum(r['supported'] for r in rows),focal=[r for r in rows if r['species']=='Peptostreptococcus stomatis' and r['metabolite']=='C01921_Glycocholate'][0])
(out/'global_BH_run_summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
print(json.dumps(summary,indent=2))
