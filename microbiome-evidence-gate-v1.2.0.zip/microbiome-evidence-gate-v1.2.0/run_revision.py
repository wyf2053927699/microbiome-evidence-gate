"""Run the portable October revision workflows; outputs stay under this folder."""
from pathlib import Path
import argparse, os, subprocess, sys

root=Path(__file__).resolve().parent
parser=argparse.ArgumentParser()
parser.add_argument('--rscript',default=os.environ.get('RSCRIPT','Rscript'))
parser.add_argument('--python-only',action='store_true')
args=parser.parse_args()
scripts=root/'07_代码与日志'
jobs=['calibrate_crc.py','run_crc_revision.py','rebuild_unified_global_BH.py','run_hcc_and_prepare_panels.py']
for name in jobs:
    print('Running',name,flush=True)
    subprocess.run([sys.executable,'-B','-X','utf8',str(scripts/name)],cwd=scripts,check=True)
if not args.python_only:
    subprocess.run([args.rscript,str(scripts/'verify_and_gca.R')],cwd=scripts,check=True)
for name in ['53_benchmark_evidence_gate_framework.py','85_framework_boundary_benchmark.py','verify_ratings_and_global_BH.py']:
    subprocess.run([sys.executable,'-B','-X','utf8',str(scripts/name)],cwd=scripts,check=True)
subprocess.run([sys.executable,'-B',str(root/'final_consistency'/'verify_target_panel.py')],cwd=root,check=True)
print('All requested revision workflows completed.',flush=True)
